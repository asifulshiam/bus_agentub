class ApiConfig {
  // ⭐ THIS IS THE IMPORTANT PART
  static const String baseUrl = 'https://web-production-9625a.up.railway.app';
  static const String wsUrl = 'wss://web-production-9625a.up.railway.app';
  
  // API endpoints
  static String get buses => '$baseUrl/buses';
  static String get login => '$baseUrl/auth/login';
  static String get register => '$baseUrl/auth/register';
  
  // Location services
  static String busLocation(int busId) => '$baseUrl/location/bus/$busId';
  static String busEta(int busId, int boardingPointId) => '$baseUrl/location/bus/$busId/eta/$boardingPointId';
  static String busRoute(int busId) => '$baseUrl/location/route/$busId';
  static String nearbyPlaces(int boardingPointId) => '$baseUrl/location/boarding-points/$boardingPointId/nearby';
  static String get geocode => '$baseUrl/location/geocode';
}
