import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:passenger/api_config.dart';
import 'package:passenger/homepage.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _nidController = TextEditingController();
  String? _selectedRole;
  bool _isLoading = false;

  final List<String> _roles = ['owner', 'supervisor', 'passenger'];
  final _storage = const FlutterSecureStorage();

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _nidController.dispose();
    super.dispose();
  }

  Future<void> _register() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      final url = Uri.parse(ApiConfig.register);
      try {
        final response = await http.post(
          url,
          headers: {'Content-Type': 'application/json'},
          body: json.encode({
            'name': _nameController.text,
            'phone': '+880${_phoneController.text.replaceAll(RegExp(r'[\s-]'), '')}',
            'password': _passwordController.text,
            'nid': _nidController.text,
            'role': _selectedRole,
          }),
        );

        if (response.statusCode == 201) {
          final data = json.decode(response.body);
          final token = data['access_token']?.toString();
          
          if (token != null && token.isNotEmpty) {
            await _storage.write(key: 'auth_token', value: token);
          }

          if (mounted) {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomePage()),
              (route) => false,
            );
          }
        } else {
          final error = _extractErrorMessage(response.body) ?? 'Registration failed';
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(error)),
            );
          }
        }
      } on SocketException {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Unable to reach the server. Please check your internet connection.')),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Registration failed: $e')),
          );
        }
      }

      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24.0),
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 30),
                      // -- Header --
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.directions_bus, size: 30, color: Colors.black),
                          SizedBox(width: 8),
                          Text(
                            'BUS AGENTub',
                            style: TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),
                      const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.person_outline, size: 24, color: Colors.black54),
                          SizedBox(width: 8),
                          Text(
                            'Register Account',
                            style: TextStyle(
                              fontSize: 20,
                              color: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 30),

                      // -- Form Container --
                      Container(
                        padding: const EdgeInsets.all(24.0),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(30.0),
                          border: Border.all(color: Colors.grey.shade300),
                        ),
                        child: Column(
                          children: [
                            _buildTextField(
                              controller: _nameController,
                              hintText: 'Enter Name',
                              helperText: 'Full name (2-100 characters)',
                              validator: (value) {
                                if (value == null || value.length < 2) {
                                  return 'Name must be at least 2 characters.';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                             _buildTextField(
                              controller: _phoneController,
                              hintText: 'Enter Phone (10 digits)',
                              helperText: 'Phone: +880XXXXXXXXXX (10 digits after +880)',
                              keyboardType: TextInputType.phone,
                              prefixText: '+880',
                              maxLength: 10,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Phone number cannot be empty.';
                                }
                                // Remove any spaces or dashes
                                final digits = value.replaceAll(RegExp(r'[\s-]'), '');
                                if (digits.length != 10) {
                                  return 'Phone must be exactly 10 digits after +880.';
                                }
                                if (!RegExp(r'^[0-9]+$').hasMatch(digits)) {
                                  return 'Phone must contain only digits.';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            _buildTextField(
                              controller: _passwordController,
                              hintText: 'Enter Password',
                              helperText: 'Password (min 8 characters)',
                              obscureText: true,
                               validator: (value) {
                                if (value == null || value.length < 8) {
                                  return 'Password must be at least 8 characters.';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                             _buildTextField(
                              controller: _nidController,
                              hintText: 'Enter NID',
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'NID cannot be empty.';
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 16),
                            _buildRoleDropdown(),
                          ],
                        ),
                      ),
                      const SizedBox(height: 100), // Space for the button
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
       floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
       floatingActionButton: _isLoading
        ? const CircularProgressIndicator()
        : Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: ElevatedButton(
              onPressed: _register,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                minimumSize: const Size.fromHeight(50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: const Text(
                'REGISTER',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
          ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hintText,
    String? helperText,
    bool obscureText = false,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    String? prefixText,
    int? maxLength,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          textAlign: prefixText != null ? TextAlign.left : TextAlign.center,
          maxLength: maxLength,
          decoration: InputDecoration(
            hintText: hintText,
            hintStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
            filled: true,
            fillColor: Colors.black,
            contentPadding: EdgeInsets.symmetric(
              vertical: 16,
              horizontal: prefixText != null ? 12 : 16,
            ),
            prefixText: prefixText,
            prefixStyle: const TextStyle(color: Colors.white70, fontSize: 16),
            counterText: '', // Hide character counter
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: BorderSide.none,
            ),
             errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: const BorderSide(color: Colors.red, width: 2.0),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: const BorderSide(color: Colors.red, width: 2.0),
            ),
          ),
          style: const TextStyle(color: Colors.white),
          validator: validator,
        ),
        if (helperText != null)
          Padding(
            padding: const EdgeInsets.only(left: 16.0, top: 4.0),
            child: Text(
              helperText,
              style: TextStyle(color: Colors.grey[600], fontSize: 12),
            ),
          ),
      ],
    );
  }

  Widget _buildRoleDropdown() {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      DropdownButtonFormField<String>(
        initialValue: _selectedRole,
        hint: const Text(
          'Role',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white70),
        ),
        isExpanded: true, // This is important
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.black,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
            borderSide: BorderSide.none,
          ),
           errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30.0),
              borderSide: const BorderSide(color: Colors.red, width: 2.0),
            ),
        ),
        dropdownColor: Colors.grey[800],
        icon: const Icon(Icons.arrow_drop_down, color: Colors.white),
        items: _roles.map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value, style: const TextStyle(color: Colors.white)),
          );
        }).toList(),
        onChanged: (String? newValue) {
          setState(() {
            _selectedRole = newValue;
          });
        },
        validator: (value) => value == null ? 'Please select a role.' : null,
      ),
       Padding(
            padding: const EdgeInsets.only(left: 16.0, top: 4.0),
            child: Text(
              'Select role',
              style: TextStyle(color: Colors.grey[600], fontSize: 12),
            ),
          ),
    ],
  );
  }

  String? _extractErrorMessage(String body) {
    try {
      final data = json.decode(body);
      if (data is Map<String, dynamic>) {
        if (data['message'] != null) return data['message'].toString();
        final detail = data['detail'];
        if (detail is String) return detail;
        if (detail is List && detail.isNotEmpty) {
          return detail
              .map((entry) => entry is Map && entry['msg'] != null ? entry['msg'] : entry.toString())
              .join('\n');
        }
      }
    } catch (_) {
      return null;
    }
    return null;
  }
}
