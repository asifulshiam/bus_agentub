import 'package:intl/intl.dart';

double? _asDouble(dynamic value) {
  if (value == null) return null;
  if (value is num) return value.toDouble();
  return double.tryParse(value.toString());
}

DateTime? _asDateTime(dynamic value) {
  if (value == null) return null;
  try {
    return DateTime.parse(value.toString()).toLocal();
  } catch (_) {
    return null;
  }
}

int? _extractBusId(Map<String, dynamic> json) {
    int? busId;
    if (json['bus_id'] != null) {
      busId = json['bus_id'] is int
          ? json['bus_id'] as int
          : int.tryParse(json['bus_id']?.toString() ?? '');
    }
    if (busId == null && json['bus'] is Map) {
      final b = json['bus'] as Map;
      if (b['id'] != null) {
        busId = b['id'] is int ? b['id'] as int : int.tryParse(b['id']?.toString() ?? '');
      } else if (b['bus_id'] != null) {
        busId = b['bus_id'] is int ? b['bus_id'] as int : int.tryParse(b['bus_id']?.toString() ?? '');
      }
    }
    if (busId == null && json['bus_details'] is Map) {
      final bd = json['bus_details'] as Map;
      if (bd['id'] != null) {
        busId = bd['id'] is int ? bd['id'] as int : int.tryParse(bd['id']?.toString() ?? '');
      } else if (bd['bus_id'] != null) {
        busId = bd['bus_id'] is int ? bd['bus_id'] as int : int.tryParse(bd['bus_id']?.toString() ?? '');
      }
    }
    if (busId == null && json['data'] is Map) {
      final data = json['data'] as Map;
      if (data['bus'] is Map) {
        final b = data['bus'] as Map;
        if (b['id'] != null) {
          busId = b['id'] is int ? b['id'] as int : int.tryParse(b['id']?.toString() ?? '');
        }
      }
      if (busId == null && data['bus_id'] != null) {
        busId = data['bus_id'] is int ? data['bus_id'] as int : int.tryParse(data['bus_id']?.toString() ?? '');
      }
    }

    if (busId == null && json['bus_id'] != null) {
       busId = int.tryParse(json['bus_id'].toString());
    }
    
    if (busId == null) {
      if (json['booking'] is Map) {
        final booking = json['booking'] as Map;
        if (booking['bus_id'] != null) {
          busId = booking['bus_id'] is int ? booking['bus_id'] as int : int.tryParse(booking['bus_id']?.toString() ?? '');
        }
      }
    }
    return busId;
}

class BusSummary {
  BusSummary({
    required this.id,
    required this.busNumber,
    required this.routeFrom,
    required this.routeTo,
    required this.departureTime,
    required this.busType,
    required this.availableSeats,
    required this.isActive,
    this.fare,
    this.supervisor,
  });

  final int id;
  final String busNumber;
  final String routeFrom;
  final String routeTo;
  final DateTime? departureTime;
  final String busType;
  final int availableSeats;
  final bool isActive;
  final double? fare;
  final String? supervisor;

  String get formattedDeparture {
    if (departureTime == null) return 'TBD';
    return DateFormat('EEE, MMM d · hh:mm a').format(departureTime!);
  }

  factory BusSummary.fromJson(Map<String, dynamic> json) {
    return BusSummary(
      id: json['id'] as int,
      busNumber: json['bus_number']?.toString() ?? 'Unknown',
      routeFrom: json['route_from']?.toString() ?? 'Unknown',
      routeTo: json['route_to']?.toString() ?? 'Unknown',
      departureTime: _asDateTime(json['departure_time']),
      busType: json['bus_type']?.toString() ?? 'N/A',
      availableSeats: json['available_seats'] is int
          ? json['available_seats'] as int
          : int.tryParse(json['available_seats']?.toString() ?? '') ?? 0,
      isActive: json['is_active'] == null ? true : json['is_active'] as bool,
      fare: _asDouble(json['fare']),
      supervisor: json['supervisor']?.toString(),
    );
  }
}

class BoardingPoint {
  BoardingPoint({
    required this.id,
    required this.busId,
    required this.name,
    required this.sequenceOrder,
    this.lat,
    this.lng,
  });

  final int id;
  final int busId;
  final String name;
  final int sequenceOrder;
  final double? lat;
  final double? lng;

  factory BoardingPoint.fromJson(Map<String, dynamic> json) {
    return BoardingPoint(
      id: json['id'] as int,
      busId: json['bus_id'] is int
          ? json['bus_id'] as int
          : int.tryParse(json['bus_id']?.toString() ?? '') ?? 0,
      name: json['name']?.toString() ?? 'Unnamed',
      sequenceOrder: json['sequence_order'] is int
          ? json['sequence_order'] as int
          : int.tryParse(json['sequence_order']?.toString() ?? '') ?? 0,
      lat: _asDouble(json['lat']),
      lng: _asDouble(json['lng']),
    );
  }
}

class BookingStatus {
  BookingStatus({
    required this.bookingId,
    required this.status,
    required this.message,
    this.busId,
    this.busNumber,
    this.routeFrom,
    this.routeTo,
    this.requestTime,
  });

  final int bookingId;
  final String status; // pending, accepted, rejected, cancelled
  final String message;
  final int? busId;
  final String? busNumber;
  final String? routeFrom;
  final String? routeTo;
  final DateTime? requestTime;

  bool get isAccepted => status == 'accepted';
  bool get isPending => status == 'pending';
  bool get isRejected => status == 'rejected';

  factory BookingStatus.fromJson(Map<String, dynamic> json) {
    return BookingStatus(
      bookingId: json['booking_id'] is int
          ? json['booking_id'] as int
          : int.tryParse(json['booking_id']?.toString() ?? '') ?? 0,
      status: json['status']?.toString() ?? 'pending',
      message: json['message']?.toString() ?? '',
      busId: _extractBusId(json),
      busNumber: json['bus_number']?.toString(),
      routeFrom: json['route_from']?.toString(),
      routeTo: json['route_to']?.toString(),
      requestTime: _asDateTime(json['request_time']),
    );
  }
}

class PendingBooking {
  PendingBooking({
    required this.bookingId,
    this.busId,
    required this.busNumber,
    required this.routeFrom,
    required this.routeTo,
    required this.status,
    this.departureTime,
    this.fare,
    this.requestTime,
  });

  final int bookingId;
  final int? busId;
  final String busNumber;
  final String routeFrom;
  final String routeTo;
  final String status;
  final DateTime? departureTime;
  final double? fare;
  final DateTime? requestTime;

  bool get needsConfirmation => status == 'accepted';

  factory PendingBooking.fromJson(Map<String, dynamic> json) {
    return PendingBooking(
      bookingId: json['booking_id'] is int
          ? json['booking_id'] as int
          : int.tryParse(json['booking_id']?.toString() ?? '') ?? 0,
      busId: _extractBusId(json),
      busNumber: json['bus_number']?.toString() ?? 'Unknown',
      routeFrom: json['route_from']?.toString() ?? 'Unknown',
      routeTo: json['route_to']?.toString() ?? 'Unknown',
      status: json['status']?.toString() ?? 'pending',
      departureTime: _asDateTime(json['departure_time']),
      fare: _asDouble(json['fare']),
      requestTime: _asDateTime(json['request_time']),
    );
  }
}

class TicketConfirmResponse {
  TicketConfirmResponse({
    required this.ticketId,
    required this.status,
    required this.seatsBooked,
    required this.totalFare,
    required this.message,
    this.boardingPoint,
    this.busDetails,
  });

  final int ticketId;
  final String status;
  final int seatsBooked;
  final double totalFare;
  final String message;
  final Map<String, dynamic>? boardingPoint;
  final Map<String, dynamic>? busDetails;

  factory TicketConfirmResponse.fromJson(Map<String, dynamic> json) {
    return TicketConfirmResponse(
      ticketId: json['ticket_id'] is int
          ? json['ticket_id'] as int
          : int.tryParse(json['ticket_id']?.toString() ?? '') ?? 0,
      status: json['status']?.toString() ?? 'confirmed',
      seatsBooked: json['seats_booked'] is int
          ? json['seats_booked'] as int
          : int.tryParse(json['seats_booked']?.toString() ?? '') ?? 0,
      totalFare: _asDouble(json['total_fare']) ?? 0.0,
      message: json['message']?.toString() ?? '',
      boardingPoint: json['boarding_point'] is Map
          ? Map<String, dynamic>.from(json['boarding_point'] as Map)
          : null,
      busDetails: json['bus_details'] is Map
          ? Map<String, dynamic>.from(json['bus_details'] as Map)
          : null,
    );
  }
}

class TicketSummary {
  TicketSummary({
    required this.id,
    required this.bookingId,
    required this.busNumber,
    required this.routeFrom,
    required this.routeTo,
    required this.status,
    required this.seatsBooked,
    required this.farePerSeat,
    required this.totalFare,
    required this.boardingPointName,
    this.busId,
    this.boardingPointId,
    this.boardingPointSequence,
    this.departureTime,
    this.boardingPointLat,
    this.boardingPointLng,
    this.createdAt,
  });

  final int id;
  final int bookingId;
  final String busNumber;
  final String routeFrom;
  final String routeTo;
  final String status;
  final int seatsBooked;
  final double? farePerSeat;
  final double? totalFare;
  final String boardingPointName;
  final int? busId;
  final int? boardingPointId;
  final int? boardingPointSequence;
  final DateTime? departureTime;
  final double? boardingPointLat;
  final double? boardingPointLng;
  final DateTime? createdAt;

  String get statusLabel => status[0].toUpperCase() + status.substring(1);

  String get createdAtFormatted {
    if (createdAt == null) return '';
    return DateFormat('MMM d, yyyy · hh:mm a').format(createdAt!);
  }

  factory TicketSummary.fromJson(Map<String, dynamic> json) {
    int? busId = _extractBusId(json);

    print('TicketSummary.fromJson: bookingId=${json['booking_id']}, extracted busId=$busId from json keys=${json.keys.toList()}');

    return TicketSummary(
      id: json['id'] as int,
      bookingId: json['booking_id'] is int
          ? json['booking_id'] as int
          : int.tryParse(json['booking_id']?.toString() ?? '') ?? 0,
      busNumber: json['bus_number']?.toString() ?? 'Unknown',
      routeFrom: json['route_from']?.toString() ?? 'Unknown',
      routeTo: json['route_to']?.toString() ?? 'Unknown',
      status: json['status']?.toString() ?? 'pending',
      seatsBooked: json['seats_booked'] is int
          ? json['seats_booked'] as int
          : int.tryParse(json['seats_booked']?.toString() ?? '') ?? 0,
      farePerSeat: _asDouble(json['fare_per_seat']),
      totalFare: _asDouble(json['total_fare']),
      boardingPointName: json['boarding_point_name']?.toString() ?? 'Unknown stop',
      busId: busId,
      boardingPointId: json['boarding_point_id'] is int
          ? json['boarding_point_id'] as int
          : int.tryParse(json['boarding_point_id']?.toString() ?? ''),
      boardingPointSequence: json['boarding_point_sequence'] is int
          ? json['boarding_point_sequence'] as int
          : int.tryParse(json['boarding_point_sequence']?.toString() ?? ''),
      departureTime: _asDateTime(json['departure_time']),
      boardingPointLat: _asDouble(json['boarding_point_lat']),
      boardingPointLng: _asDouble(json['boarding_point_lng']),
      createdAt: _asDateTime(json['created_at']),
    );
  }
}
