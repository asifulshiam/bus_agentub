import 'dart:convert';
import 'dart:io';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:passenger/api_config.dart';
import 'package:passenger/models/bus_models.dart';

class ApiException implements Exception {
  ApiException(this.message, {this.statusCode});

  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

class AuthRequiredException extends ApiException {
  AuthRequiredException()
      : super(
          'You need to login to continue.',
          statusCode: 401,
        );
}

class BusService {
  BusService({
    http.Client? client,
    FlutterSecureStorage? storage,
  })  : _client = client ?? http.Client(),
        _storage = storage ?? const FlutterSecureStorage();

  final http.Client _client;
  final FlutterSecureStorage _storage;

  Future<List<BusSummary>> fetchBuses({
    String? routeFrom,
    String? routeTo,
    String? busType,
  }) async {
    final queryParams = <String, String>{};
    if (routeFrom != null && routeFrom.isNotEmpty) {
      queryParams['route_from'] = routeFrom;
    }
    if (routeTo != null && routeTo.isNotEmpty) {
      queryParams['route_to'] = routeTo;
    }
    if (busType != null && busType.isNotEmpty) {
      queryParams['bus_type'] = busType;
    }

    final uri = Uri.parse(ApiConfig.buses).replace(queryParameters: queryParams.isEmpty ? null : queryParams);
    try {
      final response = await _client.get(uri).timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        throw ApiException(_extractMessage(response.body), statusCode: response.statusCode);
      }

      final List<dynamic> data = json.decode(response.body) as List<dynamic>;
      return data.map((item) => BusSummary.fromJson(item as Map<String, dynamic>)).toList();
    } on SocketException {
      throw ApiException('Please check your internet connection and try again.');
    }
  }

  Future<List<BoardingPoint>> fetchBoardingPoints(int busId) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/buses/$busId/stops');
    try {
      final response = await _client.get(uri).timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        throw ApiException(_extractMessage(response.body), statusCode: response.statusCode);
      }

      final List<dynamic> data = json.decode(response.body) as List<dynamic>;
      return data.map((item) => BoardingPoint.fromJson(item as Map<String, dynamic>)).toList();
    } on SocketException {
      throw ApiException('Unable to reach the Bus Agent servers. Try again once you are online.');
    }
  }

  Future<BookingStatus> requestBooking(int busId) async {
    final token = await _storage.read(key: 'auth_token');
    if (token == null) throw AuthRequiredException();

    final uri = Uri.parse('${ApiConfig.baseUrl}/booking/request');
    try {
      final response = await _client.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode({'bus_id': busId}),
      );

      if (response.statusCode != 201) {
        final message = _extractMessage(response.body);
        throw ApiException(message, statusCode: response.statusCode);
      }

      final Map<String, dynamic> data = json.decode(response.body) as Map<String, dynamic>;
      return BookingStatus.fromJson(data);
    } on SocketException {
      throw ApiException('Unable to send booking right now. Please reconnect to the internet.');
    }
  }

  Future<TicketConfirmResponse> confirmTicket({
    required int bookingId,
    required int boardingPointId,
    required int seatsBooked,
  }) async {
    final token = await _storage.read(key: 'auth_token');
    if (token == null) throw AuthRequiredException();

    final uri = Uri.parse('${ApiConfig.baseUrl}/booking/ticket/confirm');
    try {
      final response = await _client.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode({
          'booking_id': bookingId,
          'boarding_point_id': boardingPointId,
          'seats_booked': seatsBooked,
        }),
      );

      if (response.statusCode != 201) {
        final message = _extractMessage(response.body);
        throw ApiException(message, statusCode: response.statusCode);
      }

      final Map<String, dynamic> data = json.decode(response.body) as Map<String, dynamic>;
      return TicketConfirmResponse.fromJson(data);
    } on SocketException {
      throw ApiException('Unable to confirm ticket right now. Please reconnect to the internet.');
    }
  }

  Future<List<TicketSummary>> fetchMyTickets({String? statusFilter}) async {
    final token = await _storage.read(key: 'auth_token');
    if (token == null) throw AuthRequiredException();

    final query = <String, String>{};
    if (statusFilter != null && statusFilter.isNotEmpty) {
      query['status_filter'] = statusFilter;
    }

    final uri = Uri.parse('${ApiConfig.baseUrl}/booking/tickets/mine').replace(
      queryParameters: query.isEmpty ? null : query,
    );

    try {
      final response = await _client.get(
        uri,
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode != 200) {
        final message = _extractMessage(response.body);
        throw ApiException(message, statusCode: response.statusCode);
      }

      final List<dynamic> data = json.decode(response.body) as List<dynamic>;
      return data.map((item) => TicketSummary.fromJson(item as Map<String, dynamic>)).toList();
    } on SocketException {
      throw ApiException('We could not refresh your tickets while offline.');
    }
  }

  Future<void> cancelTicket(int ticketId) async {
    final token = await _storage.read(key: 'auth_token');
    if (token == null) throw AuthRequiredException();

    final uri = Uri.parse('${ApiConfig.baseUrl}/booking/ticket/cancel');
    try {
      final response = await _client.post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: json.encode({'ticket_id': ticketId}),
      );

      if (response.statusCode != 200) {
        final message = _extractMessage(response.body);
        throw ApiException(message, statusCode: response.statusCode);
      }
    } on SocketException {
      throw ApiException('Unable to reach the server to cancel this ticket right now.');
    }
  }

  Future<BookingStatus?> getBookingStatus(int bookingId) async {
    final token = await _storage.read(key: 'auth_token');
    if (token == null) throw AuthRequiredException();

    final uri = Uri.parse('${ApiConfig.baseUrl}/booking/status/$bookingId');
    try {
      final response = await _client.get(
        uri,
        headers: {'Authorization': 'Bearer $token'},
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body) as Map<String, dynamic>;
        return BookingStatus.fromJson(data);
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<List<PendingBooking>> getPendingBookings() async {
    final token = await _storage.read(key: 'auth_token');
    if (token == null) throw AuthRequiredException();

    final List<PendingBooking> pendingBookings = [];
    final Set<int> seenBookingIds = {};

    try {
      final uri = Uri.parse('${ApiConfig.baseUrl}/booking/tickets/mine').replace(
        queryParameters: {'status_filter': 'accepted'},
      );
      final response = await _client.get(
        uri,
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body) as List<dynamic>;
        print('Inbox API response from /booking/tickets/mine?status_filter=accepted: ${data.length} items');
        for (final item in data) {
          try {
            final ticket = TicketSummary.fromJson(item as Map<String, dynamic>);
            print('Inbox: Processing ticket ${ticket.bookingId} with status: ${ticket.status}, busId: ${ticket.busId}');
            final status = ticket.status.toLowerCase().trim();
            final needsConfirmation = status == 'accepted' || status == 'approved';
            
            if (needsConfirmation && !seenBookingIds.contains(ticket.bookingId)) {
              final pending = PendingBooking(
                bookingId: ticket.bookingId,
                busId: ticket.busId,
                busNumber: ticket.busNumber,
                routeFrom: ticket.routeFrom,
                routeTo: ticket.routeTo,
                status: 'accepted',
                departureTime: ticket.departureTime,
                fare: ticket.farePerSeat,
                requestTime: ticket.createdAt,
              );
              pendingBookings.add(pending);
              seenBookingIds.add(ticket.bookingId);
              print('Inbox: Added accepted booking ${ticket.bookingId} with busId=${pending.busId}');
            }
          } catch (_) {
            continue;
          }
        }
      } else if (response.statusCode == 401) {
        throw AuthRequiredException();
      }
    } catch (e) {
    }

    if (pendingBookings.isEmpty) {
      try {
        final allTickets = await fetchMyTickets();
        for (final ticket in allTickets) {
          final status = ticket.status.toLowerCase().trim();
          final needsConfirmation = status == 'accepted' || status == 'approved';

          if (needsConfirmation && !seenBookingIds.contains(ticket.bookingId)) {
            pendingBookings.add(PendingBooking(
              bookingId: ticket.bookingId,
              busId: ticket.busId,
              busNumber: ticket.busNumber,
              routeFrom: ticket.routeFrom,
              routeTo: ticket.routeTo,
              status: 'accepted',
              departureTime: ticket.departureTime,
              fare: ticket.farePerSeat,
              requestTime: ticket.createdAt,
            ));
            seenBookingIds.add(ticket.bookingId);
          }
        }
      } catch (_) {
      }
    }

    if (pendingBookings.isEmpty) {
      try {
        final uri = Uri.parse('${ApiConfig.baseUrl}/booking/my-requests');
        final response = await _client.get(
          uri,
          headers: {'Authorization': 'Bearer $token'},
        ).timeout(const Duration(seconds: 10));

        if (response.statusCode == 200) {
          final List<dynamic> data = json.decode(response.body) as List<dynamic>;
          for (final item in data) {
            try {
              final booking = PendingBooking.fromJson(item as Map<String, dynamic>);
              if (booking.needsConfirmation && !seenBookingIds.contains(booking.bookingId)) {
                pendingBookings.add(booking);
                seenBookingIds.add(booking.bookingId);
              }
            } catch (_) {
              continue;
            }
          }
        }
      } catch (_) {
      }

      try {
        final uri = Uri.parse('${ApiConfig.baseUrl}/booking/pending');
        final response = await _client.get(
          uri,
          headers: {'Authorization': 'Bearer $token'},
        ).timeout(const Duration(seconds: 10));

        if (response.statusCode == 200) {
          final List<dynamic> data = json.decode(response.body) as List<dynamic>;
          for (final item in data) {
            try {
              final booking = PendingBooking.fromJson(item as Map<String, dynamic>);
              if (booking.needsConfirmation && !seenBookingIds.contains(booking.bookingId)) {
                pendingBookings.add(booking);
                seenBookingIds.add(booking.bookingId);
              }
            } catch (_) {
              continue;
            }
          }
        }
      } catch (_) {
      }
    }

    print('Inbox: Returning ${pendingBookings.length} pending bookings total');
    return pendingBookings;
  }

  Future<BookingStatus?> checkBookingStatus(int bookingId) async {
    final token = await _storage.read(key: 'auth_token');
    if (token == null) throw AuthRequiredException();

    try {
      final uri = Uri.parse('${ApiConfig.baseUrl}/booking/status/$bookingId');
      final response = await _client.get(
        uri,
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body) as Map<String, dynamic>;
        return BookingStatus.fromJson(data);
      }
    } catch (_) {
    }

    try {
      final tickets = await fetchMyTickets();
      for (final ticket in tickets) {
        if (ticket.bookingId == bookingId) {
          return BookingStatus(
            bookingId: ticket.bookingId,
            status: ticket.status,
            message: 'Booking ${ticket.status}',
            busId: ticket.busId,
            busNumber: ticket.busNumber,
            routeFrom: ticket.routeFrom,
            routeTo: ticket.routeTo,
          );
        }
      }
    } catch (_) {
    }

    return null;
  }

  Future<Map<String, dynamic>> getBusLocation(int busId) async {
    final token = await _storage.read(key: 'auth_token');
    
    final uri = Uri.parse(ApiConfig.busLocation(busId));
    try {
      Map<String, String>? headers;
      if (token != null) {
        headers = {'Authorization': 'Bearer $token'};
      }
      
      final response = await _client.get(
        uri,
        headers: headers,
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 401) {
        throw AuthRequiredException();
      }
      
      if (response.statusCode == 404) {
        throw ApiException('Bus location not found. The bus may not be active or tracking may not be enabled.', statusCode: 404);
      }
      
      if (response.statusCode != 200) {
        throw ApiException(_extractMessage(response.body), statusCode: response.statusCode);
      }

      final responseBody = response.body.trim();
      if (responseBody.isEmpty) {
        throw ApiException('Empty response from bus location endpoint');
      }

      final data = json.decode(responseBody);

      print('Bus location raw API response: $data');

      if (data is List && data.isNotEmpty) {
        final firstItem = data[0];
        if (firstItem is Map<String, dynamic>) {
          return _extractLocationFromMap(firstItem);
        }
      }

      if (data is Map<String, dynamic>) {
        return _extractLocationFromMap(data);
      }
      
      throw ApiException('Unexpected response format from bus location endpoint');
    } on SocketException {
      throw ApiException('Unable to get bus location while offline.');
    } on FormatException catch (e) {
      throw ApiException('Invalid response format from bus location endpoint: ${e.message}');
    }
  }

  Map<String, dynamic> _extractLocationFromMap(Map<String, dynamic> data) {
    if (data.containsKey('lat') && data.containsKey('lng')) {
      return {'lat': data['lat'], 'lng': data['lng']};
    }

    if (data.containsKey('latitude') && data.containsKey('longitude')) {
      return {
        'lat': data['latitude'],
        'lng': data['longitude'],
      };
    }

    if (data.containsKey('location')) {
      final location = data['location'];
      if (location is Map<String, dynamic>) {
        if (location.containsKey('lat') && location.containsKey('lng')) {
          return {'lat': location['lat'], 'lng': location['lng']};
        }
        return _extractLocationFromMap(location);
      }
    }

    if (data.containsKey('data')) {
      final nested = data['data'];
      if (nested is Map<String, dynamic>) {
        return _extractLocationFromMap(nested);
      }
    }

    if (data.containsKey('current_location')) {
      final loc = data['current_location'];
      if (loc is Map<String, dynamic>) {
        return _extractLocationFromMap(loc);
      }
    }

    if (data.containsKey('bus_location')) {
      final loc = data['bus_location'];
      if (loc is Map<String, dynamic>) {
        return _extractLocationFromMap(loc);
      }
    }

    if (data.containsKey('coordinates') && data['coordinates'] is List) {
      final coords = data['coordinates'] as List;
      if (coords.length >= 2) {
        return {
          'lng': coords[0],
          'lat': coords[1],
        };
      }
    }

    if (data.containsKey('position')) {
      final pos = data['position'];
      if (pos is Map<String, dynamic>) {
        return _extractLocationFromMap(pos);
      }
    }

    if (data.containsKey('pos')) {
      final pos = data['pos'];
      if (pos is Map<String, dynamic>) {
        return _extractLocationFromMap(pos);
      }
    }

    return data;
  }

  Future<Map<String, dynamic>> getBusEta(int busId, int boardingPointId) async {
    final token = await _storage.read(key: 'auth_token');
    Map<String, String>? headers;
    if (token != null) {
      headers = {'Authorization': 'Bearer $token'};
    }

    final uri = Uri.parse(ApiConfig.busEta(busId, boardingPointId));
    try {
      final response = await _client.get(
        uri,
        headers: headers,
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 401) {
        throw AuthRequiredException();
      }
      
      if (response.statusCode != 200) {
        throw ApiException(_extractMessage(response.body), statusCode: response.statusCode);
      }

      final data = json.decode(response.body) as Map<String, dynamic>;
      
      if (data.containsKey('eta')) {
        return data['eta'] as Map<String, dynamic>;
      } else if (data.containsKey('data')) {
        final nested = data['data'] as Map<String, dynamic>;
        if (nested.containsKey('eta')) {
          return nested['eta'] as Map<String, dynamic>;
        }
        return nested;
      }
      
      return data;
    } on SocketException {
      throw ApiException('Unable to get ETA while offline.');
    }
  }

  Future<Map<String, dynamic>> getBusRoute(int busId) async {
    final token = await _storage.read(key: 'auth_token');
    Map<String, String>? headers;
    if (token != null) {
      headers = {'Authorization': 'Bearer $token'};
    }

    final uri = Uri.parse(ApiConfig.busRoute(busId));
    try {
      final response = await _client.get(
        uri,
        headers: headers,
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode == 401) {
        throw AuthRequiredException();
      }
      
      if (response.statusCode != 200) {
        throw ApiException(_extractMessage(response.body), statusCode: response.statusCode);
      }

      return json.decode(response.body) as Map<String, dynamic>;
    } on SocketException {
      throw ApiException('Unable to get route while offline.');
    }
  }

  Future<String?> getSupervisor(int busId) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/buses/$busId');
    try {
      final response = await _client.get(uri).timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        print('getSupervisor: API returned status ${response.statusCode} for busId=$busId');
        throw ApiException(_extractMessage(response.body), statusCode: response.statusCode);
      }

      final Map<String, dynamic> data = json.decode(response.body) as Map<String, dynamic>;
      print('getSupervisor: API response for busId=$busId: ${data.keys.toList()}');
      
      // Try multiple possible field names, prioritizing 'phone' as per API spec
      String? supervisor;
      
      // First, try direct phone field
      supervisor = data['phone']?.toString();
      
      // Then try supervisor-specific fields
      supervisor ??= data['supervisor_phone']?.toString();
      supervisor ??= data['supervisor']?.toString();
      
      // Check if there's a nested supervisor object
      if (supervisor == null && data['supervisor'] is Map) {
        final supervisorObj = data['supervisor'] as Map<String, dynamic>;
        supervisor = supervisorObj['phone']?.toString();
        supervisor ??= supervisorObj['contact']?.toString();
      }
      
      // Fallback to contact field
      supervisor ??= data['contact']?.toString();
      
      print('getSupervisor: Found supervisor=$supervisor for busId=$busId');
      return supervisor;
    } on SocketException {
      throw ApiException('Please check your internet connection and try again.');
    }
  }

  Future<String?> reverseGeocode({
    required double lat,
    required double lng,
  }) async {
    final uri = Uri.parse(
      'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$lat&lon=$lng',
    );

    try {
      final response = await _client.get(
        uri,
        headers: {
          'User-Agent': 'passenger-app/1.0 (contact: support@example.com)',
        },
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode != 200) {
        return null;
      }

      final Map<String, dynamic> data = json.decode(response.body) as Map<String, dynamic>;
      final displayName = data['display_name']?.toString();
      if (displayName != null && displayName.isNotEmpty) return displayName;

      if (data['address'] is Map<String, dynamic>) {
        final address = data['address'] as Map<String, dynamic>;
        final parts = [
          address['road'],
          address['suburb'],
          address['city'],
          address['state'],
          address['country'],
        ].whereType<String>().toList();
        if (parts.isNotEmpty) return parts.join(', ');
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<List<Map<String, dynamic>>> getNearbyPlaces(int boardingPointId, {String placeType = 'restaurant', int radius = 500}) async {
    final token = await _storage.read(key: 'auth_token');
    if (token == null) throw AuthRequiredException();

    final uri = Uri.parse(ApiConfig.nearbyPlaces(boardingPointId)).replace(
      queryParameters: {'place_type': placeType, 'radius': radius.toString()},
    );
    try {
      final response = await _client.get(
        uri,
        headers: {'Authorization': 'Bearer $token'},
      ).timeout(const Duration(seconds: 15));

      if (response.statusCode != 200) {
        throw ApiException(_extractMessage(response.body), statusCode: response.statusCode);
      }

      final List<dynamic> data = json.decode(response.body) as List<dynamic>;
      return data.cast<Map<String, dynamic>>();
    } on SocketException {
      throw ApiException('Unable to get nearby places while offline.');
    }
  }

  String _extractMessage(String body) {
    try {
      final Map<String, dynamic> data = json.decode(body) as Map<String, dynamic>;
      if (data['message'] != null) return data['message'].toString();
      final detail = data['detail'];
      if (detail is String) return detail;
      if (detail is List && detail.isNotEmpty) {
        final msgs = detail
            .map((entry) =>
                entry is Map && entry['msg'] != null ? entry['msg'].toString() : entry.toString())
            .join('\n');
        return msgs;
      }
      return 'Something went wrong';
    } catch (_) {
      return 'Something went wrong';
    }
  }
}
