import 'dart:async';
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:passenger/models/bus_models.dart';
import 'package:passenger/services/bus_service.dart';

/// Service to poll for booking status updates and notify users
class NotificationService {
  NotificationService({
    BusService? busService,
    FlutterSecureStorage? storage,
  })  : _busService = busService ?? BusService(),
        _storage = storage ?? const FlutterSecureStorage();

  final BusService _busService;
  final FlutterSecureStorage _storage;
  Timer? _pollingTimer;
  final Set<int> _trackedBookings = {};
  bool _isPolling = false;

  /// Start polling for booking status updates
  void startPolling({Duration interval = const Duration(seconds: 30)}) {
    if (_isPolling) return;
    _isPolling = true;
    _pollingTimer = Timer.periodic(interval, (_) => _checkForUpdates());
  }

  /// Stop polling for updates
  void stopPolling() {
    _isPolling = false;
    _pollingTimer?.cancel();
    _pollingTimer = null;
  }

  /// Add a booking ID to track for status updates
  void trackBooking(int bookingId) {
    _trackedBookings.add(bookingId);
  }

  /// Remove a booking ID from tracking
  void untrackBooking(int bookingId) {
    _trackedBookings.remove(bookingId);
  }

  /// Check for booking status updates
  Future<void> _checkForUpdates() async {
    if (!_isPolling) return; // Don't check if polling is stopped
    
    try {
      // Get pending bookings from local storage
      final pendingJson = await _storage.read(key: 'pending_bookings');
      final List<Map<String, dynamic>> pendingList = [];
      
      if (pendingJson != null) {
        try {
          final List<dynamic> pendingData = json.decode(pendingJson) as List<dynamic>;
          pendingList.addAll(pendingData.cast<Map<String, dynamic>>());
        } catch (_) {
          // Invalid JSON, clear corrupted data
          await _storage.delete(key: 'pending_bookings');
        }
      }

      // Also check API for any new accepted bookings
      bool apiUpdated = false;
      try {
        final apiBookings = await _busService.getPendingBookings();
        for (final apiBooking in apiBookings) {
          // Check if this booking is already in local storage
          final existingIndex = pendingList.indexWhere(
            (b) => b['booking_id'] == apiBooking.bookingId,
          );
          
          if (existingIndex >= 0) {
            // Update existing booking if status changed
            if (pendingList[existingIndex]['status'] != apiBooking.status) {
              pendingList[existingIndex] = {
                'booking_id': apiBooking.bookingId,
                'bus_id': apiBooking.busId,
                'bus_number': apiBooking.busNumber,
                'route_from': apiBooking.routeFrom,
                'route_to': apiBooking.routeTo,
                'status': apiBooking.status,
                'fare': apiBooking.fare,
                'departure_time': apiBooking.departureTime?.toIso8601String(),
                'request_time': apiBooking.requestTime?.toIso8601String() ?? DateTime.now().toIso8601String(),
              };
              apiUpdated = true;
            }
          } else {
            // Add new accepted booking
            pendingList.add({
              'booking_id': apiBooking.bookingId,
              'bus_id': apiBooking.busId,
              'bus_number': apiBooking.busNumber,
              'route_from': apiBooking.routeFrom,
              'route_to': apiBooking.routeTo,
              'status': apiBooking.status,
              'fare': apiBooking.fare,
              'departure_time': apiBooking.departureTime?.toIso8601String(),
              'request_time': apiBooking.requestTime?.toIso8601String() ?? DateTime.now().toIso8601String(),
            });
            apiUpdated = true;
          }
        }
      } on AuthRequiredException {
        // User not logged in, stop polling
        stopPolling();
        return;
      } catch (_) {
        // API might not be available, continue with local storage check
      }

      // Check each pending booking for status updates
      bool updated = false;
      for (int i = pendingList.length - 1; i >= 0; i--) {
        if (!_isPolling) return; // Stop if polling was cancelled
        
        final booking = pendingList[i];
        final bookingId = booking['booking_id'];
        if (bookingId == null) continue;

        // Check status if booking is tracked or if it's pending
        final shouldCheck = _trackedBookings.isEmpty || _trackedBookings.contains(bookingId);
        if (!shouldCheck && booking['status'] == 'accepted') {
          continue; // Already accepted, no need to check
        }

        try {
          final status = await _busService.checkBookingStatus(bookingId);
          if (status == null) continue;

          // If booking was accepted and not already in pending list as accepted
          if (status.isAccepted && booking['status'] != 'accepted') {
            // Update local storage
            booking['status'] = 'accepted';
            booking['request_time'] = DateTime.now().toIso8601String();
            updated = true;
            
            // Notify listeners (if using a stream or callback)
            _onBookingAccepted(status, booking);
          } else if (status.isRejected && booking['status'] != 'rejected') {
            // Remove rejected bookings
            pendingList.removeAt(i);
            updated = true;
          }
        } catch (_) {
          // Ignore errors for individual bookings
        }
      }

      // Save updated list if changes were made
      if (updated || apiUpdated) {
        // Filter to only accepted bookings that need confirmation
        final acceptedBookings = pendingList.where((b) => b['status'] == 'accepted').toList();
        if (acceptedBookings.isNotEmpty) {
          await _storage.write(key: 'pending_bookings', value: json.encode(acceptedBookings));
        } else {
          await _storage.delete(key: 'pending_bookings');
        }
      }
    } catch (_) {
      // Ignore polling errors
    }
  }

  /// Callback when a booking is accepted
  void _onBookingAccepted(BookingStatus status, Map<String, dynamic> booking) {
    // This can be extended to use a stream or callback pattern
    // For now, the inbox page will check on refresh
  }

  /// Get count of pending bookings that need confirmation
  Future<int> getPendingCount() async {
    try {
      final pendingJson = await _storage.read(key: 'pending_bookings');
      if (pendingJson == null) return 0;

      final List<dynamic> data = json.decode(pendingJson) as List<dynamic>;
      return data.length;
    } catch (_) {
      return 0;
    }
  }

  void dispose() {
    stopPolling();
    _trackedBookings.clear();
  }
}

