import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:passenger/homepage/bookbus.dart';
import 'package:passenger/models/bus_models.dart';
import 'package:passenger/services/bus_service.dart';

class AvailableBusPage extends StatefulWidget {
  const AvailableBusPage({super.key});

  @override
  State<AvailableBusPage> createState() => _AvailableBusPageState();
}

class _AvailableBusPageState extends State<AvailableBusPage> {
  final TextEditingController _fromController = TextEditingController();
  final TextEditingController _toController = TextEditingController();
  final BusService _busService = BusService();
  final List<String> _busTypes = const ['AC', 'Non-AC', 'AC Sleeper'];

  List<BusSummary> _buses = [];
  bool _isLoading = true;
  String? _error;
  String? _selectedType;

  @override
  void initState() {
    super.initState();
    _loadBuses();
  }

  @override
  void dispose() {
    _fromController.dispose();
    _toController.dispose();
    super.dispose();
  }

  Future<void> _loadBuses() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final buses = await _busService.fetchBuses(
        routeFrom: _fromController.text.trim().isEmpty ? null : _fromController.text.trim(),
        routeTo: _toController.text.trim().isEmpty ? null : _toController.text.trim(),
        busType: _selectedType,
      );
      if (!mounted) return;
      setState(() {
        _buses = buses;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
      });
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          'Available Buses',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadBuses,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 40),
          children: [
            _buildSearchCard(),
            const SizedBox(height: 16),
            _buildBusTypeChips(),
            const SizedBox(height: 16),
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.only(top: 40.0),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_error != null)
              _buildErrorLabel()
            else if (_buses.isEmpty)
              _buildEmptyLabel()
            else
              ..._buses.map(_buildBusTile),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          TextField(
            controller: _fromController,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'From (city or station)',
              prefixIcon: Icon(Icons.radio_button_checked),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _toController,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _loadBuses(),
            decoration: const InputDecoration(
              labelText: 'To (destination)',
              prefixIcon: Icon(Icons.flag),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _loadBuses,
              icon: const Icon(Icons.search),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              label: const Text('Search buses'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBusTypeChips() {
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemBuilder: (_, index) {
          final label = _busTypes[index];
          final selected = _selectedType == label;
          return ChoiceChip(
            label: Text(label),
            selected: selected,
            onSelected: (value) {
              setState(() {
                _selectedType = value ? label : null;
              });
              _loadBuses();
            },
            selectedColor: Colors.black,
            labelStyle: TextStyle(color: selected ? Colors.white : Colors.black87),
            backgroundColor: Colors.white,
          );
        },
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemCount: _busTypes.length,
      ),
    );
  }

  Widget _buildBusTile(BusSummary bus) {
    final fareLabel = bus.fare == null
        ? 'Dynamic fare'
        : NumberFormat.currency(locale: 'en_US', symbol: '৳').format(bus.fare);
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(13, 0, 0, 0),
            blurRadius: 12,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  '${bus.routeFrom} → ${bus.routeTo}',
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  bus.busType,
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.schedule, size: 18),
              const SizedBox(width: 6),
              Text(bus.formattedDeparture),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              const Icon(Icons.event_seat, size: 18),
              const SizedBox(width: 6),
              Text('${bus.availableSeats} seats left'),
              const SizedBox(width: 12),
              const Icon(Icons.attach_money, size: 18),
              const SizedBox(width: 4),
              Text(fareLabel),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () => _openBooking(bus),
              child: const Text('Check pickup points'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorLabel() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.red[50],
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color.fromARGB(51, 244, 67, 54)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Could not fetch buses',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(_error ?? 'Unknown error'),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: _loadBuses,
            child: const Text('Try again'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyLabel() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: const [
          Icon(Icons.directions_bus, size: 48, color: Colors.grey),
          SizedBox(height: 12),
          Text(
            'No buses match your filters',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            'Try a different destination or type to see more buses.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  void _openBooking(BusSummary bus) {
    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                bus.busNumber,
                style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text('${bus.routeFrom} → ${bus.routeTo}'),
              const SizedBox(height: 16),
              const Text('Head over to the Book tab to see stops near you.'),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const BookBusPage()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    foregroundColor: Colors.white,
                    minimumSize: const Size.fromHeight(48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  child: const Text('Open Book Bus'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
