import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import 'package:passenger/models/bus_models.dart';
import 'package:passenger/services/bus_service.dart';

class BusMapPage extends StatefulWidget {
  const BusMapPage({
    super.key,
    this.busId,
    required this.busNumber,
    required this.routeFrom,
    required this.routeTo,
    this.boardingPoint,
    this.userLocation,
  });

  final int? busId;
  final String busNumber;
  final String routeFrom;
  final String routeTo;
  final BoardingPoint? boardingPoint;
  final Position? userLocation;

  @override
  State<BusMapPage> createState() => _BusMapPageState();
}

class _BusMapPageState extends State<BusMapPage> {
  final BusService _busService = BusService();
  final MapController _mapController = MapController();
  
  LatLng? _busLocation;
  LatLng? _lastGeocodeLocation;
  String? _busAddress;
  List<LatLng> _routePoints = [];
  List<Map<String, dynamic>> _nearbyPlaces = [];
  String? _eta;
  bool _isLoading = true;
  bool _isTracking = false;
  bool _isUpdatingLocation = false;
  Timer? _locationTimer;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.busId == null || widget.busId! <= 0) {
      if (mounted) {
        setState(() {
          if (widget.boardingPoint != null) {
            _error = 'Bus tracking unavailable (Invalid Bus ID). Showing boarding point.';
          } else {
             _error = 'Invalid Bus information. Cannot load map.';
          }
          _isLoading = false;
        });
      }
      return;
    }
    _loadMapData();
    _startTracking();
  }

  @override
  void dispose() {
    _locationTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadMapData() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    print(
      'Map load start -> busId: ${widget.busId}, busNumber: ${widget.busNumber}, '
      'boardingPoint: ${widget.boardingPoint?.id}, userLoc: ${widget.userLocation?.latitude},${widget.userLocation?.longitude}',
    );

    try {
      try {
        final busLoc = await _busService.getBusLocation(widget.busId!);
        print('Bus location response for bus ${widget.busId}: $busLoc');

        final lat = double.tryParse(busLoc['lat']?.toString() ?? '');
        final lng = double.tryParse(busLoc['lng']?.toString() ?? '');

        if (lat != null && lng != null && lat.abs() <= 90 && lng.abs() <= 180) {
          if (mounted) {
            setState(() {
              _busLocation = LatLng(lat, lng);
              _error = null;
            });
            _centerMapOnBus();
            _maybeReverseGeocode(_busLocation!);
          }
        } else if (mounted) {
          setState(() => _error = 'No coordinates in response');
        }
      } catch (e) {
        if (mounted) {
          final errorMsg = e.toString();
          if (errorMsg.contains('404')) {
            setState(() => _error = 'Bus tracking not available. Check back later.');
          } else if (errorMsg.contains('offline')) {
            setState(() => _error = 'No internet connection to fetch location.');
          } else {
            setState(() => _error = 'Unable to load bus location.');
          }
        }
      }

      try {
        final route = await _busService.getBusRoute(widget.busId!);
        if (route['route_points'] != null) {
          final List<dynamic> points = route['route_points'] as List<dynamic>;
          final List<LatLng> validPoints = [];
          for (final p in points) {
            try {
              if (p is Map) {
                final latValue = p['lat'] ?? p['latitude'];
                final lngValue = p['lng'] ?? p['longitude'];
                if (latValue != null && lngValue != null) {
                  final lat = double.tryParse(latValue.toString());
                  final lng = double.tryParse(lngValue.toString());
                  if (lat != null && lng != null && lat != 0 && lng != 0) {
                    validPoints.add(LatLng(lat, lng));
                  }
                }
              }
            } catch (_) {
              continue;
            }
          }
          if (mounted) {
            setState(() {
              _routePoints = validPoints;
            });
          }
        }
      } catch (_) {
        // Route might not be available
      }

      final boardingPoint = widget.boardingPoint;
      if (boardingPoint != null) {
        await _updateEta();

        try {
          final places = await _busService.getNearbyPlaces(boardingPoint.id);
          setState(() {
            _nearbyPlaces = places;
          });
        } catch (_) {
          // Nearby places might not be available
        }
      }
    } catch (error) {
      setState(() => _error = error.toString());
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _startTracking() {
    _isTracking = true;
    _locationTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_isTracking) {
        _updateBusLocation();
        _updateEta();
      }
    });
    _updateBusLocation();
    _updateEta();
  }

  void _stopTracking() {
    _isTracking = false;
    _locationTimer?.cancel();
  }

  Future<void> _updateBusLocation() async {
    if (!mounted || widget.busId == null) return;
    setState(() => _isUpdatingLocation = true);
    
    try {
      final busLoc = await _busService.getBusLocation(widget.busId!);
      print('Bus location update response: $busLoc');

      if (!mounted) return;
      
      final lat = double.tryParse(busLoc['lat']?.toString() ?? '');
      final lng = double.tryParse(busLoc['lng']?.toString() ?? '');
      
      if (lat != null && lng != null && lat.abs() <= 90 && lng.abs() <= 180) {
        final newLocation = LatLng(lat, lng);
        
        setState(() {
          _busLocation = newLocation;
          _isUpdatingLocation = false;
          _error = null; // Clear errors on successful update
        });
        
        if (_isTracking && _busLocation != null) {
          _mapController.move(_busLocation!, _mapController.camera.zoom);
        }
        _maybeReverseGeocode(newLocation);
      } else {
        if (mounted) setState(() => _isUpdatingLocation = false);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isUpdatingLocation = false;
        });
      }
    }
  }

  Future<void> _updateEta() async {
    final boardingPoint = widget.boardingPoint;
    if (boardingPoint == null || widget.busId == null) {
      if (mounted) {
        setState(() => _eta = null);
      }
      return;
    }
    
    try {
      final etaData = await _busService.getBusEta(widget.busId!, boardingPoint.id);
      if (etaData['eta_minutes'] != null && mounted) {
        final etaMinutes = etaData['eta_minutes'];
        String etaText;
        if (etaMinutes is int || etaMinutes is double) {
          final minutes = etaMinutes is int ? etaMinutes : etaMinutes.round();
          if (minutes < 1) {
            etaText = 'Arriving now';
          } else if (minutes == 1) {
            etaText = '1 min';
          } else if (minutes < 60) {
            etaText = '$minutes min';
          } else {
            final hours = minutes ~/ 60;
            final mins = minutes % 60;
            etaText = mins > 0 ? '$hours h $mins m' : '$hours h';
          }
        } else {
          etaText = etaMinutes.toString();
        }
        
        if (mounted) {
          setState(() {
            _eta = etaText;
          });
        }
      } else if (mounted) {
        setState(() => _eta = null);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _eta = null);
      }
    }
  }

  void _centerMapOnBus() {
    if (_busLocation != null) {
      _mapController.move(_busLocation!, 15.0);
    }
  }

  void _centerMapOnBoardingPoint() {
    if (widget.boardingPoint?.lat != null && widget.boardingPoint?.lng != null) {
      final point = LatLng(widget.boardingPoint!.lat!, widget.boardingPoint!.lng!);
      _mapController.move(point, 15.0);
    }
  }

  void _centerMapOnUser() {
    if (widget.userLocation != null) {
      final point = LatLng(widget.userLocation!.latitude, widget.userLocation!.longitude);
      _mapController.move(point, 15.0);
    }
  }

  LatLng _getInitialCenter() {
    if (widget.boardingPoint?.lat != null && widget.boardingPoint?.lng != null) {
      return LatLng(widget.boardingPoint!.lat!, widget.boardingPoint!.lng!);
    }
    if (_busLocation != null) {
      return _busLocation!;
    }
    if (widget.userLocation != null) {
      return LatLng(widget.userLocation!.latitude, widget.userLocation!.longitude);
    }
    return const LatLng(23.8103, 90.4125);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _getInitialCenter(),
              initialZoom: 13.0,
              minZoom: 10.0,
              maxZoom: 18.0,
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.passenger.app',
                maxZoom: 19,
              ),
              if (_routePoints.length > 1)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: _routePoints,
                      strokeWidth: 4.0,
                      color: Colors.blue,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: [
                  if (widget.userLocation != null)
                    Marker(
                      point: LatLng(widget.userLocation!.latitude, widget.userLocation!.longitude),
                      width: 30,
                      height: 30,
                      child: const Icon(Icons.person_pin_circle, color: Colors.green, size: 30),
                    ),
                  if (widget.boardingPoint?.lat != null && widget.boardingPoint?.lng != null)
                    Marker(
                      point: LatLng(widget.boardingPoint!.lat!, widget.boardingPoint!.lng!),
                      width: 40,
                      height: 40,
                      child: const Icon(Icons.location_on, color: Colors.blue, size: 40),
                    ),
                  if (_busLocation != null)
                    Marker(
                      point: _busLocation!,
                      width: 60,
                      height: 60,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: 60,
                            height: 60,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.red.withAlpha(51),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: const BoxDecoration(
                              color: Colors.red,
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 4,
                                  offset: Offset(0, 2),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.directions_bus,
                              color: Colors.white,
                              size: 28,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ],
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(51),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.arrow_back),
                          onPressed: () => Navigator.of(context).pop(),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                widget.busNumber,
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                '${widget.routeFrom} → ${widget.routeTo}',
                                style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                              ),
                              if (_busAddress != null) ...[
                                const SizedBox(height: 2),
                                Text(
                                  _busAddress!,
                                  style: TextStyle(fontSize: 11, color: Colors.grey[600]),
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ],
                          ),
                        ),
                        if (_eta != null)
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                            decoration: BoxDecoration(
                              color: Colors.green,
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.green.withAlpha(102),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.access_time, color: Colors.white, size: 16),
                                const SizedBox(width: 6),
                                Text(
                                  _eta!,
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14,
                                  ),
                                ),
                                if (_isUpdatingLocation) ...[
                                  const SizedBox(width: 8),
                                  const SizedBox(
                                    width: 12,
                                    height: 12,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _buildControlButton(
                        icon: Icons.my_location,
                        label: 'My Location',
                        onPressed: _centerMapOnUser,
                      ),
                      const SizedBox(width: 8),
                      _buildControlButton(
                        icon: Icons.location_on,
                        label: 'Boarding',
                        onPressed: _centerMapOnBoardingPoint,
                      ),
                      const SizedBox(width: 8),
                      _buildControlButton(
                        icon: Icons.directions_bus,
                        label: 'Bus',
                        onPressed: _centerMapOnBus,
                      ),
                      const SizedBox(width: 8),
                      _buildControlButton(
                        icon: _isTracking ? Icons.pause : Icons.play_arrow,
                        label: _isTracking ? 'Pause' : 'Track',
                        onPressed: () {
                          setState(() {
                            if (_isTracking) {
                              _stopTracking();
                            } else {
                              _startTracking();
                            }
                          });
                        },
                      ),
                      if (_isUpdatingLocation)
                        const Padding(
                          padding: EdgeInsets.only(left: 8),
                          child: SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          if (widget.boardingPoint != null || _nearbyPlaces.isNotEmpty)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                constraints: const BoxConstraints(maxHeight: 200),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withAlpha(51),
                      blurRadius: 8,
                      offset: const Offset(0, -2),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 8),
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if (widget.boardingPoint != null) ...[
                              Row(
                                children: [
                                  const Icon(Icons.location_on, color: Colors.blue),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      widget.boardingPoint!.name,
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                            ],
                            if (_nearbyPlaces.isNotEmpty) ...[
                              const Text(
                                'Nearby Places',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 8),
                              SizedBox(
                                height: 60,
                                child: ListView.separated(
                                  scrollDirection: Axis.horizontal,
                                  itemCount: _nearbyPlaces.length,
                                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                                  itemBuilder: (context, index) {
                                    final place = _nearbyPlaces[index];
                                    return Container(
                                      padding: const EdgeInsets.all(12),
                                      decoration: BoxDecoration(
                                        color: Colors.grey[100],
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Icon(
                                            _getPlaceIcon(place['type']?.toString() ?? ''),
                                            size: 20,
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            place['name']?.toString() ?? 'Place',
                                            style: const TextStyle(fontSize: 10),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          if (_isLoading)
            const Center(
              child: CircularProgressIndicator(),
            ),
          if (_error != null && !_isLoading)
            Positioned(
              bottom: 100,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, color: Colors.orange),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        _error!,
                        style: const TextStyle(fontSize: 12),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 20),
                      onPressed: () => setState(() => _error = null),
                    ),
                  ],
                ),
              ),
            ),
          if (_busLocation == null && !_isLoading && widget.boardingPoint != null)
            Positioned(
              top: 100,
              left: 16,
              right: 16,
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue[50],
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.blue.shade200),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.location_off, color: Colors.blue, size: 20),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        'Bus location not available. Showing boarding point.',
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return Expanded(
      child: ElevatedButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 18),
        label: Text(label, style: const TextStyle(fontSize: 12)),
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          padding: const EdgeInsets.symmetric(vertical: 8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }

  IconData _getPlaceIcon(String type) {
    switch (type.toLowerCase()) {
      case 'restaurant':
      case 'food':
        return Icons.restaurant;
      case 'cafe':
        return Icons.local_cafe;
      case 'gas_station':
      case 'fuel':
        return Icons.local_gas_station;
      case 'hotel':
        return Icons.hotel;
      case 'atm':
        return Icons.atm;
      default:
        return Icons.place;
    }
  }

  Future<void> _maybeReverseGeocode(LatLng location) async {
    if (_lastGeocodeLocation != null) {
      final distance = const Distance().as(
        LengthUnit.Meter,
        _lastGeocodeLocation!,
        location,
      );
      if (distance < 50) return;
    }

    _lastGeocodeLocation = location;
    try {
      final address = await _busService.reverseGeocode(
        lat: location.latitude,
        lng: location.longitude,
      );
      if (!mounted) return;
      if (address != null && address.isNotEmpty) {
        setState(() => _busAddress = address);
      }
    } catch (_) {
      // Ignore reverse geocode errors
    }
  }
}
