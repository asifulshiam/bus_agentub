import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:passenger/homepage/confirm_ticket.dart';
import 'package:passenger/homepage/inbox.dart';
import 'package:passenger/models/bus_models.dart';
import 'package:passenger/services/bus_service.dart';
import 'package:passenger/services/notification_service.dart';

class BookBusPage extends StatefulWidget {
  const BookBusPage({super.key});

  @override
  State<BookBusPage> createState() => _BookBusPageState();
}

class _BookBusPageState extends State<BookBusPage> {
  final TextEditingController _destinationController = TextEditingController();
  final TextEditingController _manualPickupController = TextEditingController();
  final BusService _busService = BusService();
  final NotificationService _notificationService = NotificationService();
  final Map<int, List<BoardingPoint>> _boardingCache = {};
  final List<String> _busTypes = const ['AC', 'Non-AC', 'AC Sleeper'];

  Position? _position;
  bool _locationDenied = false;
  bool _loadingLocation = true;
  bool _loadingStations = false;
  bool _initializedSearch = false;
  bool _useManualPickup = false;

  double _radiusKm = 5;
  String? _busTypeFilter;
  int? _bookingBusId;

  List<_StationOption> _stations = [];
  Timer? _debounce;

  @override
  void initState() {
    super.initState();
    _bootstrap();
    _notificationService.startPolling(interval: const Duration(seconds: 30));
  }

  @override
  void dispose() {
    _destinationController.dispose();
    _manualPickupController.dispose();
    _debounce?.cancel();
    _notificationService.dispose();
    super.dispose();
  }

  bool get _hasGpsFix => !_locationDenied && _position != null;

  bool get _canFilterByDistance => _hasGpsFix && !_useManualPickup;

  Future<void> _bootstrap() async {
    await _determinePosition();
    await _loadStations();
  }

  Future<void> _determinePosition() async {
    setState(() {
      _loadingLocation = true;
    });
    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          _locationDenied = true;
        });
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        setState(() {
          _locationDenied = true;
        });
        return;
      }

      final position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      setState(() {
        _position = position;
        _locationDenied = false;
      });
    } catch (_) {
      setState(() {
        _locationDenied = true;
      });
    } finally {
      if (mounted) {
        setState(() {
          _loadingLocation = false;
        });
      }
    }
  }

  void _onDestinationChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 450), () {
      _loadStations();
    });
  }

  Future<void> _loadStations() async {
    setState(() {
      _loadingStations = true;
    });

    try {
      final manualQuery = _manualPickupController.text.trim().toLowerCase();
      final buses = await _busService.fetchBuses(
        routeTo: _destinationController.text.trim().isEmpty ? null : _destinationController.text.trim(),
        busType: _busTypeFilter,
      );

      final stationMap = <int, _StationOption>{};

      for (final bus in buses) {
        final stops = await _getBoardingPoints(bus.id);
        for (final stop in stops) {
          double? distanceMeters;
          if (_canFilterByDistance) {
            distanceMeters = _distanceToStop(stop);
            if (distanceMeters != null && distanceMeters > _radiusKm * 1000) {
              continue;
            }
          } else if (manualQuery.isNotEmpty && !stop.name.toLowerCase().contains(manualQuery)) {
            continue;
          }

          stationMap.putIfAbsent(
            stop.id,
            () => _StationOption(
              station: stop,
              distanceMeters: distanceMeters,
            ),
          );

          stationMap[stop.id]!.buses.add(bus);
          if (distanceMeters != null) {
            stationMap[stop.id]!.distanceMeters = _minDistance(
              stationMap[stop.id]!.distanceMeters,
              distanceMeters,
            );
          }
        }
      }

      final stations = stationMap.values.toList()
        ..sort(
          (a, b) => (a.distanceMeters ?? double.infinity).compareTo(b.distanceMeters ?? double.infinity),
        );

      if (mounted) {
        setState(() {
          _stations = stations;
          _initializedSearch = true;
        });
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString())),
      );
    } finally {
      if (mounted) {
        setState(() {
          _loadingStations = false;
        });
      }
    }
  }

  double? _distanceToStop(BoardingPoint stop) {
    if (_position == null) return null;
    if (stop.lat == null || stop.lng == null) return null;
    return Geolocator.distanceBetween(
      _position!.latitude,
      _position!.longitude,
      stop.lat!,
      stop.lng!,
    );
  }

  double? _minDistance(double? a, double? b) {
    if (a == null) return b;
    if (b == null) return a;
    return a < b ? a : b;
  }

  Future<List<BoardingPoint>> _getBoardingPoints(int busId) async {
    if (_boardingCache.containsKey(busId)) {
      return _boardingCache[busId]!;
    }
    final stops = await _busService.fetchBoardingPoints(busId);
    _boardingCache[busId] = stops;
    return stops;
  }

  Future<void> _storeBusIdMapping(int bookingId, int busId) async {
    try {
      const storage = FlutterSecureStorage();
      final mappingJson = await storage.read(key: 'booking_bus_id_map');
      final Map<String, dynamic> mapping = {};
      
      if (mappingJson != null) {
        final data = json.decode(mappingJson) as Map<String, dynamic>;
        mapping.addAll(data);
      }
      
      mapping[bookingId.toString()] = busId;
      await storage.write(key: 'booking_bus_id_map', value: json.encode(mapping));
    } catch (e) {
      print('Error storing bus_id mapping: $e');
    }
  }

  Future<void> _handleBooking(BusSummary bus) async {
    setState(() => _bookingBusId = bus.id);
    try {
      final bookingStatus = await _busService.requestBooking(bus.id);
      if (!mounted) return;

      // CRITICAL: Store permanent bus_id mapping IMMEDIATELY
      // This persists even after confirmation so we can always look it up
      await _storeBusIdMapping(bookingStatus.bookingId, bus.id);
      print('Stored PERMANENT mapping: booking_id=${bookingStatus.bookingId} → bus_id=${bus.id}');

      final pendingBooking = PendingBooking(
        bookingId: bookingStatus.bookingId,
        busId: bookingStatus.busId ?? bus.id,
        busNumber: bookingStatus.busNumber ?? bus.busNumber,
        routeFrom: bookingStatus.routeFrom ?? bus.routeFrom,
        routeTo: bookingStatus.routeTo ?? bus.routeTo,
        status: bookingStatus.status,
        fare: bus.fare,
        departureTime: bus.departureTime,
        requestTime: bookingStatus.requestTime ?? DateTime.now(),
      );

      await InboxPage.addPendingBooking(pendingBooking);
      
      _notificationService.trackBooking(bookingStatus.bookingId);

      if (bookingStatus.isAccepted) {
        if (!mounted) return;

        final confirmed = await Navigator.of(context).push<bool>(
          MaterialPageRoute(
            builder: (context) => ConfirmTicketPage(
              bookingId: bookingStatus.bookingId,
              busId: bus.id,
              busNumber: bus.busNumber,
              routeFrom: bus.routeFrom,
              routeTo: bus.routeTo,
              fare: bus.fare,
            ),
          ),
        );
        if (!mounted) return;
        
        if (confirmed == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              behavior: SnackBarBehavior.floating,
              content: Text('Ticket confirmed successfully!'),
              backgroundColor: Colors.green,
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              behavior: SnackBarBehavior.floating,
              content: Text('Booking saved to inbox. You can confirm it later.'),
            ),
          );
        }
      } else if (bookingStatus.isPending) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            content: Text(
              'Booking request sent. You\'ll be notified in inbox when accepted.',
            ),
            duration: const Duration(seconds: 4),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            content: Text(bookingStatus.message),
          ),
        );
      }
    } on AuthRequiredException catch (_) {
      if (!mounted) return;
      _showAuthRequiredSheet();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(error.toString()),
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _bookingBusId = null);
      }
    }
  }

  void _showAuthRequiredSheet() {
    showModalBottomSheet<void>(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Login required',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              const Text(
                'Please login to send a booking request. Your token is also used to show upcoming tickets.',
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Maybe later'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.black,
                        foregroundColor: Colors.white,
                        minimumSize: const Size.fromHeight(48),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      onPressed: () {
                        Navigator.of(context).pop();
                        Navigator.of(context).pop();
                      },
                      child: const Text('Go to Login'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0.5,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          'Book a Bus',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            onPressed: _loadingLocation ? null : _determinePosition,
            icon: Icon(
              Icons.my_location,
              color: _loadingLocation
                  ? Colors.grey
                  : _locationDenied
                      ? Colors.red
                      : Colors.black,
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadStations,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 24, 16, 120),
          children: [
            _buildHeroCard(),
            const SizedBox(height: 20),
            if (_useManualPickup || !_hasGpsFix) _buildManualPickupInput(),
            _buildFilters(),
            const SizedBox(height: 16),
            _buildBusTypeChips(),
            const SizedBox(height: 16),
            _buildRadiusSelector(),
            const SizedBox(height: 24),
            if (_loadingStations)
              const Center(child: CircularProgressIndicator())
            else if (_stations.isEmpty)
              _initializedSearch
                  ? _buildEmptyState()
                  : const SizedBox.shrink()
            else
              ..._stations.map(_buildStationCard),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32.0),
        child: ElevatedButton.icon(
          onPressed: _loadingStations ? null : _loadStations,
          icon: const Icon(Icons.directions_bus),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.black,
            foregroundColor: Colors.white,
            minimumSize: const Size.fromHeight(54),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
          label: Text(_loadingStations ? 'Searching...' : 'Find rides nearby'),
        ),
      ),
    );
  }

  Widget _buildHeroCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF111111), Color(0xFF2C2C2C)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(28),
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(38, 0, 0, 0),
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: const BoxDecoration(
                  color: Colors.white12,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.radio_button_checked, color: Colors.white),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Your pickup', style: TextStyle(color: Colors.white60)),
                    const SizedBox(height: 4),
                    Text(
                      _hasGpsFix && !_useManualPickup
                          ? 'Near your current position'
                          : _loadingLocation && !_useManualPickup
                              ? 'Locating you...'
                              : 'Manual pickup mode',
                      style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: _loadingLocation ? null : _determinePosition,
                icon: Icon(
                  Icons.refresh,
                  color: _loadingLocation ? Colors.white24 : Colors.white70,
                ),
              ),
              const SizedBox(width: 4),
              TextButton(
                onPressed: () {
                  setState(() {
                    _useManualPickup = !_useManualPickup;
                  });
                },
                child: Text(
                  _useManualPickup ? 'Use GPS' : 'Manual',
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Opacity(
            opacity: 0.8,
            child: Row(
              children: const [
                Icon(Icons.layers, color: Colors.white54),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Tap "Find rides" to discover active buses with real-time pickup points around you.',
                    style: TextStyle(color: Colors.white70),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildManualPickupInput() {
    return Container(
      margin: const EdgeInsets.only(top: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: const [
              Icon(Icons.edit_location_alt, color: Colors.black),
              SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Manual pickup filter',
                  style: TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _manualPickupController,
            decoration: InputDecoration(
              hintText: 'Type your nearest bus stop or area',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(color: Colors.grey.shade300),
              ),
            ),
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _loadStations(),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: _loadingStations ? null : _loadStations,
              child: const Text('Apply manual pickup'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilters() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Where are you heading?',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _destinationController,
          textInputAction: TextInputAction.search,
          onChanged: _onDestinationChanged,
          onSubmitted: (_) => _loadStations(),
          decoration: InputDecoration(
            hintText: 'Destination city or terminal',
            prefixIcon: const Icon(Icons.flag_circle_outlined),
            suffixIcon: _destinationController.text.isEmpty
                ? null
                : IconButton(
                    onPressed: () {
                      _destinationController.clear();
                      _loadStations();
                    },
                    icon: const Icon(Icons.close),
                  ),
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18),
              borderSide: BorderSide(color: Colors.grey.shade200),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildBusTypeChips() {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemBuilder: (context, index) {
          final label = _busTypes[index];
          final bool selected = _busTypeFilter == label;
          return ChoiceChip(
            label: Text(label),
            selected: selected,
            onSelected: (value) {
              setState(() {
                _busTypeFilter = value ? label : null;
              });
              _loadStations();
            },
            selectedColor: Colors.black,
            labelStyle: TextStyle(color: selected ? Colors.white : Colors.black87),
            backgroundColor: Colors.white,
          );
        },
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemCount: _busTypes.length,
      ),
    );
  }

  Widget _buildRadiusSelector() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.radar, color: Colors.black),
              const SizedBox(width: 8),
              const Text(
                'Pickup radius',
                style: TextStyle(fontWeight: FontWeight.w600),
              ),
              const Spacer(),
              Text('${_radiusKm.toStringAsFixed(1)} km'),
            ],
          ),
          Slider(
            min: 1,
            max: 20,
            divisions: 38,
            label: '${_radiusKm.toStringAsFixed(1)} km',
            activeColor: _useManualPickup ? Colors.grey : Colors.black,
            value: _radiusKm,
            onChanged: _useManualPickup
                ? null
                : (value) {
                    setState(() => _radiusKm = value);
                  },
            onChangeEnd: _useManualPickup ? null : (_) => _loadStations(),
          ),
          Text(
            _useManualPickup
                ? 'Radius filtering is disabled while you type a manual pickup.'
                : 'We filter boarding points within $_radiusKm km of your position.',
            style: TextStyle(color: Colors.grey[600]),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          const Icon(Icons.travel_explore, size: 48, color: Colors.grey),
          const SizedBox(height: 12),
          const Text(
            'No buses nearby',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'Try expanding your radius or search another destination.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey[600]),
          ),
        ],
      ),
    );
  }

  Widget _buildStationCard(_StationOption option) {
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(13, 0, 0, 0),
            blurRadius: 12,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                height: 46,
                width: 46,
                decoration: const BoxDecoration(
                  color: Colors.black,
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.location_on, color: Colors.white),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      option.station.name,
                      style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    if (option.distanceMeters != null)
                      Text(
                        '${(option.distanceMeters! / 1000).toStringAsFixed(2)} km from you',
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${option.buses.length} buses',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...option.buses.map(_buildBusTile),
        ],
      ),
    );
  }

  Widget _buildBusTile(BusSummary bus) {
    final currency = bus.fare != null ? NumberFormat.currency(locale: 'en_US', symbol: '৳').format(bus.fare) : 'Dynamic fare';
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  '${bus.routeFrom} → ${bus.routeTo}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  bus.busType,
                  style: const TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.schedule, size: 18, color: Colors.grey[700]),
              const SizedBox(width: 6),
              Text(bus.formattedDeparture),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Icon(Icons.airline_seat_recline_normal, size: 18, color: Colors.grey[700]),
              const SizedBox(width: 6),
              Text('${bus.availableSeats} seats left'),
              const SizedBox(width: 12),
              Icon(Icons.attach_money, size: 18, color: Colors.grey[700]),
              const SizedBox(width: 4),
              Text(currency),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: _bookingBusId == bus.id ? null : () => _handleBooking(bus),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: _bookingBusId == bus.id
                  ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Text('Request seat'),
            ),
          ),
        ],
      ),
    );
  }
}

class _StationOption {
  _StationOption({
    required this.station,
    this.distanceMeters,
  });

  final BoardingPoint station;
  final List<BusSummary> buses = [];
  double? distanceMeters;
}
