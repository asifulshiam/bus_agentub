import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:passenger/homepage/bus_map.dart';
import 'package:passenger/models/bus_models.dart';
import 'package:passenger/services/bus_service.dart';
import 'package:url_launcher/url_launcher.dart';

class MyTicketPage extends StatefulWidget {
  const MyTicketPage({super.key});

  @override
  State<MyTicketPage> createState() => _MyTicketPageState();
}

class _MyTicketPageState extends State<MyTicketPage> {
  final BusService _busService = BusService();
  List<TicketSummary> _tickets = [];
  final Map<int, String> _etaMap = {}; // Map of ticket ID to ETA
  bool _isLoading = true;
  bool _authRequired = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadTickets();
  }

  Future<void> _loadTickets() async {
    setState(() {
      _isLoading = true;
      _error = null;
      _authRequired = false;
    });
    try {
      final tickets = await _busService.fetchMyTickets();
      if (!mounted) return;
      setState(() {
        _tickets = tickets;
      });
      
      // Load ETA for confirmed tickets with bus and boarding point info
      _loadEtasForTickets(tickets);
    } on AuthRequiredException {
      if (!mounted) return;
      setState(() {
        _authRequired = true;
        _tickets = [];
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = error.toString());
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<void> _loadEtasForTickets(List<TicketSummary> tickets) async {
    for (final ticket in tickets) {
      // Only load ETA for confirmed tickets with bus and boarding point info
      if (ticket.status == 'confirmed' && 
          ticket.busId != null && 
          ticket.boardingPointId != null) {
        try {
          final etaData = await _busService.getBusEta(ticket.busId!, ticket.boardingPointId!);
          if (etaData['eta_minutes'] != null && mounted) {
            final etaMinutes = etaData['eta_minutes'];
            String etaText;
            if (etaMinutes is int || etaMinutes is double) {
              final minutes = etaMinutes is int ? etaMinutes : etaMinutes.round();
              if (minutes < 1) {
                etaText = 'Arriving now';
              } else if (minutes == 1) {
                etaText = '1 min';
              } else if (minutes < 60) {
                etaText = '$minutes min';
              } else {
                final hours = minutes ~/ 60;
                final mins = minutes % 60;
                etaText = mins > 0 ? '$hours h $mins m' : '$hours h';
              }
            } else {
              etaText = etaMinutes.toString();
            }
            
            if (mounted) {
              setState(() {
                _etaMap[ticket.id] = etaText;
              });
            }
          }
        } catch (_) {
          // Ignore ETA errors for individual tickets
        }
      }
    }
  }

  Future<void> _cancelTicket(TicketSummary ticket) async {
    try {
      await _busService.cancelTicket(ticket.id);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('Ticket ${ticket.id} cancelled.'),
        ),
      );
      await _loadTickets();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text(error.toString()),
        ),
      );
    }
  }

  Future<void> _callSupervisor(TicketSummary ticket) async {
    // Get bus_id using same logic as map view
    int? busId = ticket.busId;
    
    if (busId == null) {
      const storage = FlutterSecureStorage();
      try {
        final mappingJson = await storage.read(key: 'booking_bus_id_map');
        if (mappingJson != null) {
          final Map<String, dynamic> mapping = json.decode(mappingJson) as Map<String, dynamic>;
          busId = mapping[ticket.bookingId.toString()] as int?;
        }
      } catch (_) {
        // Ignore storage errors
      }
    }

    if (busId == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('Cannot get supervisor contact: Bus information not available'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    try {
      final supervisor = await _busService.getSupervisor(busId);
      if (supervisor != null && supervisor.isNotEmpty) {
        final Uri launchUri = Uri(
          scheme: 'tel',
          path: supervisor,
        );
        await launchUrl(launchUri);
      } else {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            behavior: SnackBarBehavior.floating,
            content: Text('Supervisor contact not available for this bus'),
            backgroundColor: Colors.orange,
          ),
        );
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('Failed to get supervisor contact: ${error.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          'My Tickets',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadTickets,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(20),
          children: [
            if (_isLoading)
              const Padding(
                padding: EdgeInsets.only(top: 60.0),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (_authRequired)
              _buildAuthRequiredCard()
            else if (_error != null)
              _buildErrorState()
            else if (_tickets.isEmpty)
              _buildEmptyState()
            else
              ..._tickets.map(_buildTicketCard),
          ],
        ),
      ),
    );
  }

  Widget _buildAuthRequiredCard() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Login required',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Text(
            'Sign in to view tickets you have booked and manage their status.',
          ),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () => Navigator.of(context).pushNamed('/login'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.black,
                foregroundColor: Colors.white,
                minimumSize: const Size.fromHeight(48),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              ),
              child: const Text('Go to Login'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.red[50],
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color.fromARGB(51, 244, 67, 54)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Could not load tickets',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(_error ?? 'Unknown error'),
          const SizedBox(height: 16),
          OutlinedButton(
            onPressed: _loadTickets,
            child: const Text('Retry'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        children: [
          const Icon(Icons.confirmation_num_outlined, size: 48, color: Colors.grey),
          const SizedBox(height: 12),
          const Text(
            'No tickets yet',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'Book a bus to see tickets appear here.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.grey[600]),
          ),
        ],
      ),
    );
  }

  Widget _buildTicketCard(TicketSummary ticket) {
    final statusColor = _statusColor(ticket.status);
    return Container(
      margin: const EdgeInsets.only(bottom: 18),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: const [
          BoxShadow(
            color: Color.fromARGB(13, 0, 0, 0),
            blurRadius: 12,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  '${ticket.routeFrom} → ${ticket.routeTo}',
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: statusColor.withAlpha((0.1 * 255).round()),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  ticket.statusLabel,
                  style: TextStyle(color: statusColor, fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _infoRow(Icons.confirmation_num_outlined, 'Bus', ticket.busNumber),
          const SizedBox(height: 6),
          _infoRow(Icons.event, 'Departure', ticket.departureTime == null ? 'TBD' : DateFormat('EEE, MMM d · hh:mm a').format(ticket.departureTime!)),
          const SizedBox(height: 6),
          _infoRow(Icons.event_seat, 'Seats', '${ticket.seatsBooked} · ৳${(ticket.totalFare ?? 0).toStringAsFixed(0)}'),
          const SizedBox(height: 6),
          _infoRow(Icons.location_on_outlined, 'Boarding', ticket.boardingPointName),
          if (ticket.status == 'confirmed' && _etaMap.containsKey(ticket.id)) ...[
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.green[50],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green.shade200),
              ),
              child: Row(
                children: [
                  Icon(Icons.access_time, color: Colors.green[700], size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'ETA: ${_etaMap[ticket.id]}',
                    style: TextStyle(
                      color: Colors.green[700],
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _showBoardingPointHint(ticket),
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text('Map'),
                ),
              ),
              if (ticket.status == 'confirmed') ...[
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _callSupervisor(ticket),
                    style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    icon: const Icon(Icons.phone, size: 18),
                    label: const Text('Call'),
                  ),
                ),
              ],
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton(
                  onPressed: ticket.status == 'confirmed' ? () => _cancelTicket(ticket) : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: const Text('Cancel'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 18, color: Colors.grey[700]),
        const SizedBox(width: 8),
        Text(
          '$label:',
          style: TextStyle(color: Colors.grey[700]),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
        ),
      ],
    );
  }

  Color _statusColor(String status) {
    switch (status) {
      case 'confirmed':
        return Colors.green;
      case 'completed':
        return Colors.blue;
      case 'cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  Future<void> _showBoardingPointHint(TicketSummary ticket) async {
    // Get user location if available
    Position? userLocation;
    try {
      userLocation = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
    } catch (_) {
      // User location not available, continue without it
    }

    // CRITICAL FIX: API doesn't return bus_id, so we need to fetch it from local storage
    // using booking_id as the lookup key
    int? busId = ticket.busId;
    
    if (busId == null) {
      const storage = FlutterSecureStorage();
      try {
        // First, try the permanent mapping (most reliable)
        final mappingJson = await storage.read(key: 'booking_bus_id_map');
        if (mappingJson != null) {
          final Map<String, dynamic> mapping = json.decode(mappingJson) as Map<String, dynamic>;
          final bookingIdKey = ticket.bookingId.toString();
          if (mapping.containsKey(bookingIdKey)) {
            busId = mapping[bookingIdKey] as int?;
            print('Found bus_id=$busId for booking_id=${ticket.bookingId} in permanent mapping');
          }
        }
        
        // Fallback: Try pending_bookings (for backwards compatibility)
        if (busId == null) {
          final pendingJson = await storage.read(key: 'pending_bookings');
          if (pendingJson != null) {
            final List<dynamic> data = json.decode(pendingJson) as List<dynamic>;
            for (final item in data) {
              if (item['booking_id'] == ticket.bookingId) {
                busId = item['bus_id'] as int?;
                print('Found bus_id=$busId for booking_id=${ticket.bookingId} in pending_bookings');
                break;
              }
            }
          }
        }
        
        // Last resort: Search for bus by bus_number (for old bookings)
        if (busId == null && ticket.busNumber.isNotEmpty) {
          print('Searching for bus_id by bus_number: ${ticket.busNumber}');
          try {
            final buses = await _busService.fetchBuses();
            for (final bus in buses) {
              if (bus.busNumber == ticket.busNumber) {
                busId = bus.id;
                print('Found bus_id=$busId by matching bus_number=${ticket.busNumber}');
                // Store this for future use
                final Map<String, dynamic> mapping = {};
                final existingJson = await storage.read(key: 'booking_bus_id_map');
                if (existingJson != null) {
                  mapping.addAll(json.decode(existingJson) as Map<String, dynamic>);
                }
                mapping[ticket.bookingId.toString()] = busId;
                await storage.write(key: 'booking_bus_id_map', value: json.encode(mapping));
                break;
              }
            }
          } catch (e) {
            print('Error searching for bus by number: $e');
          }
        }
      } catch (e) {
        print('Error fetching bus_id from local storage: $e');
      }
    }

    // Create boarding point from ticket data
    BoardingPoint? boardingPoint;
    if (ticket.boardingPointLat != null && ticket.boardingPointLng != null) {
      boardingPoint = BoardingPoint(
        id: ticket.boardingPointId ?? 0,
        busId: busId ?? 0,
        name: ticket.boardingPointName,
        sequenceOrder: ticket.boardingPointSequence ?? 0,
        lat: ticket.boardingPointLat,
        lng: ticket.boardingPointLng,
      );
    }

    // Debug: Log what busId we're using
    print('Opening map for ticket ${ticket.id}: busId=$busId (from ${ticket.busId != null ? "API" : "local storage"}), bookingId=${ticket.bookingId}');
    
    if (!mounted) return;

    // Open map screen
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => BusMapPage(
          busId: busId,
          busNumber: ticket.busNumber,
          routeFrom: ticket.routeFrom,
          routeTo: ticket.routeTo,
          boardingPoint: boardingPoint,
          userLocation: userLocation,
        ),
      ),
    );
  }
}
