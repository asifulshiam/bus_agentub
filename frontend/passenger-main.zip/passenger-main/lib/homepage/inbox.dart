import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:intl/intl.dart';
import 'package:passenger/homepage/confirm_ticket.dart';
import 'package:passenger/models/bus_models.dart';
import 'package:passenger/services/bus_service.dart';

class InboxPage extends StatefulWidget {
  const InboxPage({super.key});

  static Future<void> addPendingBooking(PendingBooking booking) async {
    const storage = FlutterSecureStorage();
    try {
      final pendingJson = await storage.read(key: 'pending_bookings');
      final List<Map<String, dynamic>> pendingList = [];

      if (pendingJson != null) {
        final List<dynamic> data = json.decode(pendingJson) as List<dynamic>;
        pendingList.addAll(data.cast<Map<String, dynamic>>());
      }

      if (!pendingList.any((item) => item['booking_id'] == booking.bookingId)) {
        pendingList.add({
          'booking_id': booking.bookingId,
          'bus_id': booking.busId,
          'bus_number': booking.busNumber,
          'route_from': booking.routeFrom,
          'route_to': booking.routeTo,
          'status': booking.status,
          'fare': booking.fare,
          'departure_time': booking.departureTime?.toIso8601String(),
          'request_time': booking.requestTime?.toIso8601String(),
        });
        await storage.write(key: 'pending_bookings', value: json.encode(pendingList));
      }
    } catch (_) {
      // Ignore storage errors
    }
  }

  @override
  State<InboxPage> createState() => _InboxPageState();
}

class _InboxPageState extends State<InboxPage> {
  final BusService _busService = BusService();
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  List<PendingBooking> _pendingBookings = [];
  bool _isLoading = true;
  bool _authRequired = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadPendingBookings();
  }

  Future<void> _loadPendingBookings() async {
    setState(() {
      _isLoading = true;
      _error = null;
      _authRequired = false;
    });

    try {
      List<PendingBooking> apiBookings = [];
      bool apiSuccess = false;
      try {
        apiBookings = await _busService.getPendingBookings();
        apiSuccess = true;
      } on AuthRequiredException {
        if (!mounted) return;
        setState(() {
          _authRequired = true;
          _isLoading = false;
        });
        return;
      } catch (_) {
      }

      final List<PendingBooking> localBookings = [];
      try {
        final pendingJson = await _storage.read(key: 'pending_bookings');
        if (pendingJson != null) {
          final List<dynamic> data = json.decode(pendingJson) as List<dynamic>;
          localBookings.addAll(
            data.map((item) => PendingBooking.fromJson(item as Map<String, dynamic>)),
          );
        }
      } catch (_) {
        await _storage.delete(key: 'pending_bookings');
      }

      final Map<int, PendingBooking> finalBookingsMap = {};

      for (final localBooking in localBookings) {
        finalBookingsMap[localBooking.bookingId] = localBooking;
      }

      if (apiSuccess) {
        for (final apiBooking in apiBookings) {
          if (finalBookingsMap.containsKey(apiBooking.bookingId)) {
            final local = finalBookingsMap[apiBooking.bookingId]!;
            finalBookingsMap[apiBooking.bookingId] = PendingBooking(
              bookingId: apiBooking.bookingId,
              busId: apiBooking.busId ?? local.busId,
              busNumber: apiBooking.busNumber,
              routeFrom: apiBooking.routeFrom,
              routeTo: apiBooking.routeTo,
              status: apiBooking.status,
              departureTime: apiBooking.departureTime,
              fare: apiBooking.fare,
              requestTime: apiBooking.requestTime,
            );
          } else {
            finalBookingsMap[apiBooking.bookingId] = apiBooking;
          }
        }
      }

      try {
        final toStore = finalBookingsMap.values
            .where((b) => b.needsConfirmation)
            .map((b) => <String, dynamic>{
                  'booking_id': b.bookingId,
                  'bus_id': b.busId,
                  'bus_number': b.busNumber,
                  'route_from': b.routeFrom,
                  'route_to': b.routeTo,
                  'status': b.status,
                  'fare': b.fare,
                  'departure_time': b.departureTime?.toIso8601String(),
                  'request_time': b.requestTime?.toIso8601String(),
                })
            .toList();
        if (toStore.isNotEmpty) {
          await _storage.write(key: 'pending_bookings', value: json.encode(toStore));
        } else {
          await _storage.delete(key: 'pending_bookings');
        }
      } catch (_) {}

      if (!mounted) return;
      setState(() {
        _pendingBookings = finalBookingsMap.values.toList();
        _pendingBookings.sort((a, b) => (b.requestTime ?? DateTime.now()).compareTo(a.requestTime ?? DateTime.now()));
        _isLoading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.toString();
        _isLoading = false;
      });
    }
  }

  Future<void> _removePendingBooking(int bookingId) async {
    final pendingJson = await _storage.read(key: 'pending_bookings');
    if (pendingJson != null) {
      final List<dynamic> data = json.decode(pendingJson) as List<dynamic>;
      data.removeWhere((item) => item['booking_id'] == bookingId);
      await _storage.write(key: 'pending_bookings', value: json.encode(data));
    }
    await _loadPendingBookings();
  }

  Future<void> _handleConfirm(PendingBooking booking) async {
    if (booking.busId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('Cannot confirm ticket: Bus ID is missing.'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    final confirmed = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (context) => ConfirmTicketPage(
          bookingId: booking.bookingId,
          busId: booking.busId!,
          busNumber: booking.busNumber,
          routeFrom: booking.routeFrom,
          routeTo: booking.routeTo,
          fare: booking.fare,
        ),
      ),
    );

    if (confirmed == true) {
      if (!mounted) return;
      await _removePendingBooking(booking.bookingId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          behavior: SnackBarBehavior.floating,
          content: Text('Ticket confirmed successfully!'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.black),
        title: const Text(
          'Inbox',
          style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadPendingBookings,
            color: Colors.black,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadPendingBookings,
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : _authRequired
                ? _buildAuthRequiredCard()
                : _error != null
                    ? _buildErrorState()
                    : _pendingBookings.isEmpty
                        ? _buildEmptyState()
                        : ListView(
                            physics: const AlwaysScrollableScrollPhysics(),
                            padding: const EdgeInsets.all(20),
                            children: [
                              const Text(
                                'Pending Confirmations',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 16),
                              ..._pendingBookings.map(_buildNotificationCard),
                            ],
                          ),
      ),
    );
  }

  Widget _buildAuthRequiredCard() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.login, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            const Text(
              'Login required',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Please login to view your booking notifications.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            const Text(
              'Error loading inbox',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(_error ?? 'Unknown error'),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: _loadPendingBookings,
              child: const Text('Retry'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.inbox_outlined, size: 64, color: Colors.grey),
            const SizedBox(height: 16),
            const Text(
              'No notifications',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'You\'ll see booking confirmations here when supervisors accept your requests.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNotificationCard(PendingBooking booking) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue[50]!, Colors.blue[100]!],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.blue.shade300, width: 2),
        boxShadow: [
          BoxShadow(
            color: Colors.blue.withAlpha(51),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blue.withAlpha(102),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(Icons.notifications_active, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Booking Accepted!',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (booking.requestTime != null)
                      Text(
                        DateFormat('MMM d, hh:mm a').format(booking.requestTime!),
                        style: TextStyle(
                          fontSize: 12,
                          color: Colors.grey[700],
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.directions_bus, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      booking.busNumber,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      '${booking.routeFrom} → ${booking.routeTo}',
                      style: const TextStyle(fontSize: 14),
                    ),
                    if (booking.fare != null)
                      Text(
                        '৳${booking.fare!.toStringAsFixed(0)}',
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                  ],
                ),
                if (booking.departureTime != null) ...[
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.schedule, size: 16, color: Colors.grey),
                      const SizedBox(width: 4),
                      Text(
                        DateFormat('EEE, MMM d · hh:mm a').format(booking.departureTime!),
                        style: TextStyle(fontSize: 12, color: Colors.grey[700]),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => _removePendingBooking(booking.bookingId),
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Dismiss'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: () => _handleConfirm(booking),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text('Confirm Ticket'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
