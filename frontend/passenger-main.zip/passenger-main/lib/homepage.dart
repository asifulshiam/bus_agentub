import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:passenger/homepage/availablebus.dart';
import 'package:passenger/homepage/bookbus.dart';
import 'package:passenger/homepage/inbox.dart';
import 'package:passenger/homepage/myticket.dart';
import 'package:passenger/login.dart';
import 'package:passenger/services/notification_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FlutterSecureStorage _storage = const FlutterSecureStorage();
  final NotificationService _notificationService = NotificationService();
  int _inboxCount = 0;
  bool _isLoggedIn = false;

  @override
  void initState() {
    super.initState();
    _checkAuthStatus();
    _loadInboxCount();
    // Start polling for booking status updates if user is logged in
    _startNotificationPolling();
  }

  @override
  void dispose() {
    _notificationService.dispose();
    super.dispose();
  }

  Future<void> _startNotificationPolling() async {
    try {
      final token = await _storage.read(key: 'auth_token');
      if (token != null && token.isNotEmpty) {
        // Start polling every 30 seconds for booking status updates
        _notificationService.startPolling(interval: const Duration(seconds: 30));
      } else {
        // Stop polling if user is not logged in
        _notificationService.stopPolling();
      }
    } catch (_) {
      // Ignore errors
    }
  }

  Future<void> _checkAuthStatus() async {
    try {
      final token = await _storage.read(key: 'auth_token');
      if (mounted) {
        setState(() {
          _isLoggedIn = token != null && token.isNotEmpty;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() => _isLoggedIn = false);
      }
    }
  }

  Future<void> _loadInboxCount() async {
    try {
      final pendingJson = await _storage.read(key: 'pending_bookings');
      int count = 0;
      if (pendingJson != null) {
        try {
          final List<dynamic> data = json.decode(pendingJson) as List<dynamic>;
          // Count only accepted bookings that need confirmation
          for (final item in data) {
            if (item is Map && item['status'] == 'accepted') {
              count++;
            }
          }
        } catch (_) {
          // Invalid JSON, clear it
          await _storage.delete(key: 'pending_bookings');
        }
      }
      if (mounted) {
        setState(() {
          _inboxCount = count;
        });
      }
    } catch (_) {
      // Ignore errors
    }
  }

  Future<void> _handleLogout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _storage.delete(key: 'auth_token');
      // Stop notification polling on logout
      _notificationService.stopPolling();
      if (mounted) {
        setState(() {
          _isLoggedIn = false;
          _inboxCount = 0; // Clear inbox count on logout
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Logged out successfully'),
            backgroundColor: Colors.green,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Row(
          children: [
            Icon(Icons.directions_bus, color: Colors.black, size: 30),
            SizedBox(width: 8),
            Text(
              'BUS AGENTub',
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
          ],
        ),
        automaticallyImplyLeading: false,
        actions: [
          SizedBox(
            width: 70, // Constrain width to prevent overflow
            child: TextButton(
              onPressed: () async {
                if (_isLoggedIn) {
                  await _handleLogout();
                } else {
                  await Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => const Login()),
                  );
                  // Refresh auth status when returning from login
                  if (mounted) {
                    await _checkAuthStatus();
                    // Start polling if user logged in
                    await _startNotificationPolling();
                  }
                }
              },
              style: TextButton.styleFrom(
                padding: EdgeInsets.zero,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isLoggedIn ? Icons.logout : Icons.login,
                    color: Colors.black,
                    size: 28,
                  ),
                  Text(
                    _isLoggedIn ? 'Logout' : 'Login',
                    style: const TextStyle(color: Colors.black, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 1),
        ],
      ),
      body: Stack(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    const Text(
                      'Homepage',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 60.0, horizontal: 20.0),
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey.shade400, width: 2),
                        borderRadius: BorderRadius.circular(30),
                      ),
                      child: Column(
                        children: [
                          _buildInfoButton(
                            title: 'Available Bus',
                            subtitle: 'See all the available Buses',
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const AvailableBusPage()),
                              );
                            },
                          ),
                          const SizedBox(height: 50),
                          _buildInfoButton(
                            title: 'My Ticket',
                            subtitle: 'Your booked ticket',
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const MyTicketPage()),
                              );
                            },
                          ),
                          const SizedBox(height: 70),
                          _buildBookBusButton(),
                          const SizedBox(height: 20),
                          const Text(
                            'Tap to open the live bus finder',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.grey),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            left: 30,
            bottom: 30,
            child: _buildInboxButton(),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoButton({required String title, required String subtitle, VoidCallback? onPressed}) {
    return Column(
      children: [
        ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.black,
            minimumSize: const Size(260, 40),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            ),
          ),
          child: Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          subtitle,
          style: const TextStyle(color: Colors.grey),
        ),
      ],
    );
  }

  Widget _buildBookBusButton() {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const BookBusPage()),
        );
      },
      onLongPress: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const BookBusPage()),
        );
      },
      child: Container(
        width: 140,
        height: 140,
        decoration: const BoxDecoration(
          color: Colors.black,
          shape: BoxShape.circle,
        ),
        child: const Center(
          child: Text(
            'Book\nBus',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInboxButton() {
    return InkWell(
      onTap: () async {
        final result = await Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const InboxPage()),
        );
        // Refresh count when returning from inbox
        _loadInboxCount();
      },
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Stack(
            alignment: Alignment.topRight,
            children: [
              const Icon(Icons.inbox_outlined, color: Colors.black, size: 40),
              if (_inboxCount > 0)
                Container(
                  padding: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                  ),
                  constraints: const BoxConstraints(
                    minWidth: 16,
                    minHeight: 16,
                  ),
                  child: Text(
                    _inboxCount.toString(),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
            ],
          ),
          const Text('INBOX', style: TextStyle(color: Colors.black)),
        ],
      ),
    );
  }
}
