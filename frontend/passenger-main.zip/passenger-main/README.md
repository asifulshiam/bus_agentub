# Passenger App

A Flutter-based bus booking application that allows users to search for available buses, request bookings, confirm tickets, and manage their reservations in real-time.

## Features

- **User Authentication**: Login/Register with phone number, password, NID, and role selection (passenger/owner/supervisor)
- **Bus Search**: Filter buses by route, destination, and bus type (AC/Non-AC/Sleeper)
- **Real-Time Booking**: Request bus bookings and track booking status
- **Ticket Confirmation**: Confirm tickets with boarding point selection and seat management
- **Live Bus Tracking**: View bus location on interactive map with route visualization
- **Ticket Management**: View, manage, and cancel confirmed tickets
- **ETA Tracking**: Real-time estimated time of arrival at boarding points
- **Inbox Notifications**: Receive and manage pending booking confirmations
- **Nearby Places**: Discover restaurants and facilities near boarding points
- **GPS Integration**: Auto-detect user location for booking pickup points

## Architecture

### Core Components
- **Screens**: HomePage, Login, Register, AvailableBusPage, BookBusPage, ConfirmTicketPage, MyTicketPage, BusMapPage, InboxPage
- **Services**: BusService (API calls), NotificationService (polling for updates)
- **Models**: BusSummary, BookingStatus, TicketSummary, PendingBooking, BoardingPoint
- **Storage**: Secure storage for JWT tokens via `flutter_secure_storage`

### Data Flow
1. User authenticates → JWT token stored securely
2. Searches available buses → `GET /buses` with filters
3. Requests booking → `POST /booking/request`
4. Inbox fetches pending confirmations → `GET /booking/tickets/mine?status_filter=accepted`
5. User confirms ticket with boarding point → `POST /booking/ticket/confirm`
6. Map loads bus location and route → `GET /location/bus/{id}`, `GET /location/route/{id}`
7. My Tickets displays confirmed tickets with ETA → `GET /booking/tickets/mine`

## API Endpoints

### Authentication
- `POST /auth/login` - Login with phone and password
- `POST /auth/register` - Register new user (name, phone, password, nid, role)

### Bus Search
- `GET /buses` - List buses (query: route_from, route_to, bus_type)
- `GET /buses/{id}/stops` - Get boarding points for a bus

### Bookings & Tickets
- `POST /booking/request` - Request a bus booking
- `GET /booking/tickets/mine` - Fetch user's tickets (query: status_filter)
- `POST /booking/ticket/confirm` - Confirm a ticket with boarding point
- `POST /booking/ticket/cancel` - Cancel a confirmed ticket

### Location Services
- `GET /location/bus/{id}` - Get current bus location (lat/lng)
- `GET /location/bus/{id}/eta/{boardingPointId}` - Get ETA to boarding point
- `GET /location/route/{id}` - Get bus route polyline points
- `GET /location/boarding-points/{id}/nearby` - Get nearby places

## Getting Started

### Prerequisites
- Flutter SDK: ^3.9.0
- Dart SDK: ^3.9.0
- iOS deployment target: 12.0+
- Android minimum SDK: 21

### Installation

```bash
# Clone repository
git clone <repo-url>
cd passenger

# Install dependencies
flutter pub get

# Run the app
flutter run

# Run on specific device
flutter run -d <device-id>
```

### Build

**Android:**
```bash
flutter build apk              # Debug APK
flutter build apk --release    # Release APK
```

**iOS:**
```bash
flutter build ios              # Debug build
flutter build ios --release    # Release build
```

## Key Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `flutter` | SDK | Core framework |
| `http` | ^1.2.1 | REST API calls |
| `flutter_secure_storage` | ^9.2.2 | Secure token storage |
| `geolocator` | ^10.1.0 | GPS location services |
| `flutter_map` | ^7.0.2 | Interactive maps |
| `latlong2` | ^0.9.1 | Coordinate handling |
| `intl` | ^0.19.0 | Date/time formatting |
| `lottie` | ^3.1.2 | JSON animations |
| `cupertino_icons` | ^1.0.8 | iOS-style icons |

## Project Structure

```
lib/
├── main.dart                    # App entry point
├── api_config.dart              # API endpoints configuration
├── homepage.dart                # Main dashboard
├── login.dart                   # Login screen
├── register.dart                # Registration screen
├── splash_screen.dart           # App splash screen
├── homepage/
│   ├── availablebus.dart        # Bus listing page
│   ├── bookbus.dart             # Bus booking with search
│   ├── bus_map.dart             # Real-time bus map & tracking
│   ├── confirm_ticket.dart      # Ticket confirmation
│   ├── inbox.dart               # Pending confirmations
│   └── myticket.dart            # User's confirmed tickets
├── models/
│   └── bus_models.dart          # All data models
├── services/
│   ├── bus_service.dart         # API & business logic
│   └── notification_service.dart # Booking status polling
```


## Debugging

### Enable Console Logging
```bash
flutter run -v    # Verbose output
flutter logs      # Stream device logs
```

### Common Debug Points
- Check `TicketSummary.fromJson` logs for busId extraction
- Check `Map load start` logs to verify busId passed to map
- Check API response format if location returns 404

### Test Endpoints

```bash
# Get accepted bookings
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://web-production-9625a.up.railway.app/booking/tickets/mine?status_filter=accepted" | jq .

# Get bus location
curl -H "Authorization: Bearer YOUR_TOKEN" \
  "https://web-production-9625a.up.railway.app/location/bus/1" | jq .
```

## State Management

The app uses **StatefulWidget** pattern with `setState()` for UI updates:
- No external state management library (Provider/Bloc)
- Local state per page/screen
- Secure storage for auth token
- Service layer handles API calls and business logic



## License

Proprietary - Bus Agent Application

