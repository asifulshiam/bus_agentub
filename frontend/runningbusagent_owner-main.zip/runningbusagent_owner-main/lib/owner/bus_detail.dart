import 'package:busapp/config/api_config.dart';
import 'package:busapp/config/theme.dart';
import 'package:busapp/owner/add_edit_bus.dart';
import 'package:busapp/owner/add_edit_stop.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:async';
import 'dart:math' as math;
import 'package:intl/intl.dart';

class BusDetailPage extends StatefulWidget {
  final int busId;

  const BusDetailPage({super.key, required this.busId});

  @override
  State<BusDetailPage> createState() => _BusDetailPageState();
}

class _BusDetailPageState extends State<BusDetailPage> {
  Map<String, dynamic>? _busData;
  List<dynamic> _stops = [];
  Map<String, dynamic>? _busLocation;
  Map<String, dynamic>? _routeData;
  bool _isLoading = true;
  String? _error;
  final MapController _mapController = MapController();
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _loadBusDetails();
    // Auto-refresh location every 10 seconds
    _refreshTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (mounted) {
        _loadLiveLocation();
        _loadRouteData();
      }
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  Future<void> _loadBusDetails() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      final headers = await ApiConfig.getAuthHeaders();
      
      // Fetch bus details
      final busResponse = await http.get(
        Uri.parse(ApiConfig.bus(widget.busId)),
        headers: headers,
      );

      // Fetch stops
      final stopsResponse = await http.get(
        Uri.parse(ApiConfig.busStops(widget.busId)),
        headers: {
          'Content-Type': 'application/json',
        },
      );

      if (busResponse.statusCode == 200 && stopsResponse.statusCode == 200) {
        final stopsData = jsonDecode(stopsResponse.body);
        setState(() {
          _busData = jsonDecode(busResponse.body);
          _stops = stopsData is List ? stopsData : [];
          _isLoading = false;
        });
        _centerMapOnStops();
        // Load live location and route data
        _loadLiveLocation();
        _loadRouteData();
      } else {
        setState(() {
          _error = 'Failed to load bus details';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Network error: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadLiveLocation() async {
    try {
      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.get(
        Uri.parse(ApiConfig.busLocation(widget.busId)),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            _busLocation = data is Map<String, dynamic> ? Map<String, dynamic>.from(data) : null;
          });
          // Re-center map to include live location if available
          if (_busLocation != null && _busLocation!['has_location'] == true) {
            _centerMapOnStops();
          }
        }
      }
    } catch (e) {
      // Silently fail - location might not be available yet
      print('Error loading live location: $e');
    }
  }

  Future<void> _loadRouteData() async {
    try {
      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.get(
        Uri.parse(ApiConfig.route(widget.busId)),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(() {
            _routeData = data is Map<String, dynamic> ? Map<String, dynamic>.from(data) : null;
          });
        }
      }
    } catch (e) {
      // Silently fail - route data might not be available
      print('Error loading route data: $e');
    }
  }

  void _centerMapOnStops() {
    List<LatLng> points = [];
    
    // Add live bus location if available and GPS is on
    if (_busLocation != null && 
        _busLocation!['has_location'] == true &&
        _busLocation!['location'] != null) {
      final loc = _busLocation!['location'];
      final lat = (loc['lat'] as num?)?.toDouble();
      final lng = (loc['lng'] as num?)?.toDouble();
      if (lat != null && lng != null) {
        points.add(LatLng(lat, lng));
      }
    }
    
    // Add all stops
    for (var stop in _stops) {
      final lat = double.tryParse(stop['lat']?.toString() ?? '0') ?? 0.0;
      final lng = double.tryParse(stop['lng']?.toString() ?? '0') ?? 0.0;
      if (lat != 0.0 && lng != 0.0) {
        points.add(LatLng(lat, lng));
      }
    }
    
    if (points.isNotEmpty) {
      // Calculate bounds
      double minLat = points.first.latitude;
      double maxLat = points.first.latitude;
      double minLng = points.first.longitude;
      double maxLng = points.first.longitude;
      
      for (var point in points) {
        if (point.latitude < minLat) minLat = point.latitude;
        if (point.latitude > maxLat) maxLat = point.latitude;
        if (point.longitude < minLng) minLng = point.longitude;
        if (point.longitude > maxLng) maxLng = point.longitude;
      }
      
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _mapController.fitBounds(
          LatLngBounds(
            LatLng(minLat, minLng),
            LatLng(maxLat, maxLng),
          ),
          options: const FitBoundsOptions(padding: EdgeInsets.all(50)),
        );
      });
    } else if (_stops.isNotEmpty) {
      // Fallback to first stop
      final firstStop = _stops.first;
      final lat = double.tryParse(firstStop['lat']?.toString() ?? '0') ?? 23.8103;
      final lng = double.tryParse(firstStop['lng']?.toString() ?? '0') ?? 90.4125;
      
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _mapController.move(LatLng(lat, lng), 11.0);
      });
    }
  }

  Future<void> _deleteStop(int stopId) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Stop'),
        content: const Text('Are you sure you want to delete this boarding point?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.dangerColor,
            ),
            child: const Text('DELETE'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.delete(
        Uri.parse(ApiConfig.busStop(widget.busId, stopId)),
        headers: headers,
      );

      if (response.statusCode == 200 || response.statusCode == 204) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Stop deleted successfully'),
              backgroundColor: AppTheme.secondaryColor,
            ),
          );
        }
        _loadBusDetails();
      } else {
        final errorData = jsonDecode(response.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorData['detail'] ?? 'Failed to delete stop'),
              backgroundColor: AppTheme.dangerColor,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: AppTheme.dangerColor,
          ),
        );
      }
    }
  }

  String _formatBusType(String? type) {
    if (type == null) return 'Unknown';
    // Backend returns: "AC", "Non-AC", "AC Sleeper"
    final normalized = type.trim();
    if (normalized == 'AC' || normalized == 'Non-AC' || normalized == 'AC Sleeper') {
      return normalized;
    }
    // Handle legacy formats if any
    switch (normalized.toUpperCase()) {
      case 'NON_AC':
        return 'Non-AC';
      case 'AC_SLEEPER':
        return 'AC Sleeper';
      default:
        return normalized;
    }
  }

  String? _formatDepartureTime(String? timeStr) {
    if (timeStr == null) return null;
    try {
      final dateTime = DateTime.parse(timeStr);
      return DateFormat('MMM dd, yyyy - hh:mm a').format(dateTime);
    } catch (e) {
      return timeStr;
    }
  }

  String _formatLastUpdate(String? timestamp) {
    if (timestamp == null || timestamp.isEmpty) return 'Never';
    try {
      final dt = DateTime.parse(timestamp).toLocal();
      final now = DateTime.now();
      final difference = now.difference(dt);

      if (difference.inMinutes < 1) {
        return 'just now';
      } else if (difference.inHours < 1) {
        return '${difference.inMinutes} min ago';
      } else if (difference.inDays < 1) {
        return '${difference.inHours} hr ago';
      } else {
        return DateFormat('MMM dd, HH:mm').format(dt);
      }
    } catch (e) {
      return 'N/A';
    }
  }

  @override
  Widget build(BuildContext context) {
    return _isLoading
        ? const Center(child: CircularProgressIndicator())
        : _error != null
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.error_outline,
                      size: 64,
                      color: AppTheme.dangerColor,
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(
                        _error!,
                        style: const TextStyle(color: AppTheme.dangerColor),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _loadBusDetails,
                      child: const Text('RETRY'),
                    ),
                  ],
                ),
              )
            : _busData == null
                ? const Center(child: Text('No bus data available'))
                : RefreshIndicator(
                    onRefresh: _loadBusDetails,
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Bus Info Card
                          _buildBusInfoCard(),
                          const SizedBox(height: 24),

                          // Map View
                          if (_stops.isNotEmpty) ...[
                            _buildMapCard(),
                            const SizedBox(height: 24),
                          ],

                          // Boarding Points Section
                          _buildBoardingPointsSection(),
                        ],
                      ),
                    ),
                  );
  }

  Widget _buildBusInfoCard() {
    final isActive = _busData!['is_active'] == true;
    final busType = _formatBusType(_busData!['bus_type']?.toString());

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.directions_bus,
                    size: 32,
                    color: AppTheme.primaryColor,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _busData!['bus_number'] ?? 'N/A',
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.textPrimary,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${_busData!['route_from'] ?? 'N/A'} → ${_busData!['route_to'] ?? 'N/A'}',
                        style: const TextStyle(
                          fontSize: 16,
                          color: AppTheme.textSecondary,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: isActive
                        ? AppTheme.secondaryColor.withValues(alpha: 0.1)
                        : Colors.grey.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: isActive ? AppTheme.secondaryColor : Colors.grey,
                    ),
                  ),
                  child: Text(
                    isActive ? 'Active' : 'Inactive',
                    style: TextStyle(
                      color: isActive ? AppTheme.secondaryColor : Colors.grey[700],
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildInfoItem(
                    'Bus Type',
                    busType,
                    Icons.local_offer,
                  ),
                ),
                Expanded(
                  child: _buildInfoItem(
                    'Fare',
                    '৳${_busData!['fare'] ?? '0'}',
                    Icons.attach_money,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildInfoItem(
                    'Capacity',
                    '${_busData!['seat_capacity'] ?? '0'} seats',
                    Icons.event_seat,
                  ),
                ),
                Expanded(
                  child: _buildInfoItem(
                    'Available',
                    '${_busData!['available_seats'] ?? '0'} seats',
                    Icons.check_circle,
                  ),
                ),
              ],
            ),
            if (_formatDepartureTime(_busData!['departure_time']?.toString()) != null) ...[
              const SizedBox(height: 16),
              _buildInfoItem(
                'Departure',
                _formatDepartureTime(_busData!['departure_time']?.toString())!,
                Icons.access_time,
              ),
            ],
            if (_busData!['supervisor']?['name'] != null) ...[
              const SizedBox(height: 16),
              _buildInfoItem(
                'Supervisor',
                _busData!['supervisor']!['name'],
                Icons.person,
              ),
            ],
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton.icon(
                  onPressed: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AddEditBusPage(busData: _busData),
                      ),
                    );
                    if (result == true) {
                      _loadBusDetails();
                    }
                  },
                  icon: const Icon(Icons.edit, size: 18),
                  label: const Text('Edit Bus'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoItem(String label, String value, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 16, color: AppTheme.textSecondary),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: AppTheme.textSecondary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimary,
          ),
        ),
      ],
    );
  }

  Widget _buildMapCard() {
    if (_stops.isEmpty) {
      return const SizedBox.shrink();
    }

    final hasLiveLocation = _busLocation != null && 
                           _busLocation!['has_location'] == true &&
                           _busLocation!['location'] != null &&
                           _busLocation!['location']['lat'] != null;
    
    final gpsTurnedOff = _busLocation != null && _busLocation!['has_location'] == false;

    return Card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const Icon(Icons.map, color: AppTheme.primaryColor),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Route Map (${_stops.length} stops)',
                        style: Theme.of(context).textTheme.titleLarge,
                      ),
                      if (hasLiveLocation) ...[
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: AppTheme.secondaryColor,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Flexible(
                              child: Text(
                                'Live location active',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.secondaryColor,
                                  fontWeight: FontWeight.w500,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            if (_busLocation!['location']?['last_update'] != null) ...[
                              const SizedBox(width: 8),
                              Flexible(
                                child: Text(
                                  _formatLastUpdate(_busLocation!['location']?['last_update']),
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: AppTheme.textSecondary,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ],
                        ),
                      ] else if (gpsTurnedOff) ...[
                        const SizedBox(height: 4),
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: AppTheme.dangerColor,
                                shape: BoxShape.circle,
                              ),
                            ),
                            const SizedBox(width: 4),
                            Flexible(
                              child: Text(
                                'GPS turned off',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.dangerColor,
                                  fontWeight: FontWeight.w500,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Flexible(
                              child: Text(
                                'Location tracking unavailable',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: AppTheme.textSecondary,
                                ),
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.refresh),
                  tooltip: 'Refresh Location',
                  onPressed: () {
                    _loadLiveLocation();
                    _loadRouteData();
                  },
                ),
              ],
            ),
          ),
          SizedBox(
            height: 400,
            child: FlutterMap(
              mapController: _mapController,
              options: MapOptions(
                initialCenter: const LatLng(23.8103, 90.4125),
                initialZoom: 11.0,
                minZoom: 5.0,
                maxZoom: 18.0,
              ),
              children: [
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'com.busagentub.app',
                  maxZoom: 18,
                ),
                MarkerLayer(
                  markers: _buildMapMarkers(),
                ),
                PolylineLayer(
                  polylines: _buildMapPolylines(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  List<Marker> _buildMapMarkers() {
    List<Marker> markers = [];
    
    // Add current bus location marker if available and GPS is on
    if (_busLocation != null && 
        _busLocation!['has_location'] == true &&
        _busLocation!['location'] != null) {
      final loc = _busLocation!['location'];
      final lat = (loc['lat'] as num?)?.toDouble();
      final lng = (loc['lng'] as num?)?.toDouble();
      
      if (lat != null && lng != null) {
        markers.add(
          Marker(
            point: LatLng(lat, lng),
            width: 60,
            height: 60,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AppTheme.secondaryColor,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.4),
                        spreadRadius: 2,
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.directions_bus,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppTheme.secondaryColor,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.2),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                  child: const Text(
                    'LIVE',
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    }
    
    // Add boarding point markers
    for (int i = 0; i < _stops.length; i++) {
      final stop = _stops[i];
      final lat = double.tryParse(stop['lat']?.toString() ?? '0') ?? 0.0;
      final lng = double.tryParse(stop['lng']?.toString() ?? '0') ?? 0.0;

      if (lat != 0.0 && lng != 0.0) {
        markers.add(
          Marker(
            point: LatLng(lat, lng),
            width: 50,
            height: 50,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 3),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.3),
                        spreadRadius: 1,
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Text(
                    '${i + 1}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.2),
                        blurRadius: 4,
                      ),
                    ],
                  ),
                  child: Text(
                    stop['name'] ?? 'Stop ${i + 1}',
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      }
    }
    
    return markers;
  }

  List<Polyline> _buildMapPolylines() {
    List<Polyline> polylines = [];
    
    // Use route directions from API if available
    if (_routeData != null && _routeData!['route_directions'] != null) {
      final routeDirections = _routeData!['route_directions'];
      if (routeDirections['geometry'] != null) {
        // Decode polyline from route directions
        try {
          final geometry = routeDirections['geometry'];
          if (geometry is List) {
            List<LatLng> routePoints = [];
            for (var point in geometry) {
              if (point is List && point.length >= 2) {
                routePoints.add(LatLng(
                  (point[1] as num).toDouble(),
                  (point[0] as num).toDouble(),
                ));
              }
            }
            if (routePoints.isNotEmpty) {
              polylines.add(
                Polyline(
                  points: routePoints,
                  color: AppTheme.primaryColor,
                  strokeWidth: 4.0,
                ),
              );
              return polylines;
            }
          }
        } catch (e) {
          print('Error parsing route geometry: $e');
        }
      }
    }
    
    // Fallback: Use boarding points to create polyline
    if (_stops.length < 2) return [];

    List<LatLng> points = [];
    for (var stop in _stops) {
      final lat = double.tryParse(stop['lat']?.toString() ?? '0') ?? 0.0;
      final lng = double.tryParse(stop['lng']?.toString() ?? '0') ?? 0.0;
      if (lat != 0.0 && lng != 0.0) {
        points.add(LatLng(lat, lng));
      }
    }

    if (points.isEmpty) return [];

    polylines.add(
      Polyline(
        points: points,
        color: AppTheme.primaryColor,
        strokeWidth: 3.0,
      ),
    );
    
    // Add line from live location to nearest stop if available and GPS is on
    if (_busLocation != null && 
        _busLocation!['has_location'] == true &&
        _busLocation!['location'] != null && 
        points.isNotEmpty) {
      final loc = _busLocation!['location'];
      final busLat = (loc['lat'] as num?)?.toDouble();
      final busLng = (loc['lng'] as num?)?.toDouble();
      
      if (busLat != null && busLng != null) {
        // Find nearest stop
        LatLng? nearestStop;
        double minDistance = double.infinity;
        
        for (var point in points) {
          final distance = _calculateDistance(busLat, busLng, point.latitude, point.longitude);
          if (distance < minDistance) {
            minDistance = distance;
            nearestStop = point;
          }
        }
        
        if (nearestStop != null) {
          polylines.add(
            Polyline(
              points: [LatLng(busLat, busLng), nearestStop],
              color: AppTheme.secondaryColor,
              strokeWidth: 2.0,
              isDotted: true,
            ),
          );
        }
      }
    }

    return polylines;
  }
  
  double _calculateDistance(double lat1, double lng1, double lat2, double lng2) {
    // Simple distance calculation (Haversine formula)
    const double earthRadius = 6371; // km
    final dLat = (lat2 - lat1) * (math.pi / 180);
    final dLng = (lng2 - lng1) * (math.pi / 180);
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1 * (math.pi / 180)) *
            math.cos(lat2 * (math.pi / 180)) *
            math.sin(dLng / 2) *
            math.sin(dLng / 2);
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return earthRadius * c;
  }

  Widget _buildBoardingPointsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Boarding Points',
              style: Theme.of(context).textTheme.displaySmall,
            ),
            ElevatedButton.icon(
              onPressed: () async {
                final result = await showDialog(
                  context: context,
                  builder: (context) => AddEditStopDialog(busId: widget.busId),
                );
                if (result == true) {
                  _loadBusDetails();
                }
              },
              icon: const Icon(Icons.add_location, size: 18),
              label: const Text('Add Stop'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        if (_stops.isEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(32),
              child: Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.location_off,
                      size: 64,
                      color: Colors.grey[400],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'No boarding points added',
                      style: TextStyle(color: Colors.grey[600]),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: () async {
                        final result = await showDialog(
                          context: context,
                          builder: (context) => AddEditStopDialog(busId: widget.busId),
                        );
                        if (result == true) {
                          _loadBusDetails();
                        }
                      },
                      icon: const Icon(Icons.add),
                      label: const Text('Add First Stop'),
                    ),
                  ],
                ),
              ),
            ),
          )
        else
          ..._stops.asMap().entries.map((entry) {
            final index = entry.key;
            final stop = entry.value;
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppTheme.primaryColor,
                  child: Text(
                    '${index + 1}',
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
                title: Text(
                  stop['name'] ?? 'Unknown',
                  style: const TextStyle(fontWeight: FontWeight.w600),
                ),
                subtitle: Text(
                  'Lat: ${stop['lat']}, Lng: ${stop['lng']}',
                  style: TextStyle(fontSize: 12, color: AppTheme.textSecondary),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit),
                      tooltip: 'Edit',
                      onPressed: () async {
                        final result = await showDialog(
                          context: context,
                          builder: (context) => AddEditStopDialog(
                            busId: widget.busId,
                            stopData: stop,
                          ),
                        );
                        if (result == true) {
                          _loadBusDetails();
                        }
                      },
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: AppTheme.dangerColor),
                      tooltip: 'Delete',
                      onPressed: () => _deleteStop(stop['id']),
                    ),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }
}
