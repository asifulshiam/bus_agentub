import 'package:busapp/config/api_config.dart';
import 'package:busapp/config/theme.dart';
import 'package:busapp/services/boarding_points_service.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AddEditStopDialog extends StatefulWidget {
  final int busId;
  final Map<String, dynamic>? stopData; // If provided, we're editing

  const AddEditStopDialog({
    super.key,
    required this.busId,
    this.stopData,
  });

  @override
  State<AddEditStopDialog> createState() => _AddEditStopDialogState();
}

class _AddEditStopDialogState extends State<AddEditStopDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _sequenceOrderController = TextEditingController();

  bool _isLoading = false;
  List<BoardingPoint> _boardingPoints = [];
  BoardingPoint? _selectedBoardingPoint;

  @override
  void initState() {
    super.initState();
    _loadBoardingPoints();
    
    if (widget.stopData != null) {
      // Editing existing stop
      _nameController.text = widget.stopData!['name'] ?? '';
      _sequenceOrderController.text =
          widget.stopData!['sequence_order']?.toString() ?? '';
      // Boarding point matching will happen after loading in _loadBoardingPoints
    } else {
      // Adding new stop - default sequence order
      _sequenceOrderController.text = '1';
    }
  }

  Future<void> _loadBoardingPoints() async {
    final points = await BoardingPointsService.getAll();
    setState(() {
      _boardingPoints = points;
      
      // If editing, try to match boarding point after loading
      if (widget.stopData != null) {
        final stopLat = widget.stopData!['lat'];
        final stopLng = widget.stopData!['lng'];
        if (stopLat != null && stopLng != null) {
          final latValue = (stopLat as num).toDouble();
          final lngValue = (stopLng as num).toDouble();
          
          // Try to find matching boarding point (with small tolerance for floating point comparison)
          try {
            _selectedBoardingPoint = points.firstWhere(
              (point) => (point.lat - latValue).abs() < 0.0001 && 
                         (point.lng - lngValue).abs() < 0.0001,
            );
          } catch (e) {
            // No matching boarding point found - leave as null (user can select one or keep current)
            _selectedBoardingPoint = null;
          }
        }
      }
    });
  }

  void _onBoardingPointSelected(BoardingPoint? point) {
    setState(() {
      _selectedBoardingPoint = point;
      if (point != null) {
        _nameController.text = point.name;
      } else if (widget.stopData == null) {
        // Only clear name when adding new stop and deselecting
        _nameController.clear();
      }
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _sequenceOrderController.dispose();
    super.dispose();
  }

  Future<void> _saveStop() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // When adding, require a boarding point to be selected
    if (widget.stopData == null && _selectedBoardingPoint == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a boarding point'),
          backgroundColor: AppTheme.dangerColor,
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final headers = await ApiConfig.getAuthHeaders();
      
      // Get lat/lng from selected boarding point
      final lat = _selectedBoardingPoint?.lat ?? 0.0;
      final lng = _selectedBoardingPoint?.lng ?? 0.0;
      
      // If editing and no boarding point selected, use existing values
      final finalLat = widget.stopData != null && _selectedBoardingPoint == null
          ? (widget.stopData!['lat'] as num?)?.toDouble() ?? 0.0
          : lat;
      final finalLng = widget.stopData != null && _selectedBoardingPoint == null
          ? (widget.stopData!['lng'] as num?)?.toDouble() ?? 0.0
          : lng;
      
      final body = {
        'name': _nameController.text.trim(),
        'lat': finalLat,
        'lng': finalLng,
        'sequence_order': int.tryParse(_sequenceOrderController.text) ?? 1,
      };

      if (widget.stopData != null) {
        // Update existing stop
        final stopId = widget.stopData!['id'];
        final response = await http.put(
          Uri.parse(ApiConfig.busStop(widget.busId, stopId)),
          headers: headers,
          body: jsonEncode(body),
        );

        if (response.statusCode == 200) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Boarding point updated successfully'),
                backgroundColor: AppTheme.secondaryColor,
              ),
            );
            Navigator.pop(context, true);
          }
        } else {
          final errorData = jsonDecode(response.body);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(errorData['detail'] ?? 'Failed to update boarding point'),
              ),
            );
          }
        }
      } else {
        // Create new stop
        final response = await http.post(
          Uri.parse(ApiConfig.busStops(widget.busId)),
          headers: headers,
          body: jsonEncode(body),
        );

        if (response.statusCode == 200 || response.statusCode == 201) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Boarding point added successfully'),
                backgroundColor: AppTheme.secondaryColor,
              ),
            );
            Navigator.pop(context, true);
          }
        } else {
          final errorData = jsonDecode(response.body);
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(errorData['detail'] ?? 'Failed to add boarding point'),
              ),
            );
          }
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.stopData != null ? 'Edit Boarding Point' : 'Add Boarding Point'),
      content: SizedBox(
        width: MediaQuery.of(context).size.width * 0.8,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Boarding point selection dropdown (required when adding)
                DropdownButtonFormField<BoardingPoint?>(
                  decoration: InputDecoration(
                    labelText: 'Select Boarding Point *',
                    border: const OutlineInputBorder(),
                    helperText: widget.stopData == null
                        ? 'Choose a location from saved boarding points'
                        : 'Select a boarding point (optional)',
                  ),
                  value: _selectedBoardingPoint,
                  items: [
                    DropdownMenuItem<BoardingPoint?>(
                      value: null,
                      child: Text(widget.stopData == null
                          ? '-- Select a boarding point --'
                          : '-- Keep current location --'),
                    ),
                    ..._boardingPoints.map((point) {
                      return DropdownMenuItem<BoardingPoint?>(
                        value: point,
                        child: Text('${point.name} (${point.lat.toStringAsFixed(4)}, ${point.lng.toStringAsFixed(4)})'),
                      );
                    }),
                  ],
                  onChanged: _onBoardingPointSelected,
                  validator: widget.stopData == null
                      ? (value) {
                          if (value == null) {
                            return 'Please select a boarding point';
                          }
                          return null;
                        }
                      : null,
                ),
                const SizedBox(height: 16),
                
                // Name field
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Name *',
                    border: OutlineInputBorder(),
                    hintText: 'e.g., Mohakhali Bus Stand',
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter name';
                    }
                    return null;
                  },
                ),
                
                // Display lat/lng info when boarding point is selected (read-only)
                if (_selectedBoardingPoint != null) ...[
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.backgroundColor,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.grey.withValues(alpha: 0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.location_on, size: 20, color: AppTheme.primaryColor),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'Location',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.textSecondary,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Lat: ${_selectedBoardingPoint!.lat.toStringAsFixed(6)}, Lng: ${_selectedBoardingPoint!.lng.toStringAsFixed(6)}',
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: AppTheme.textPrimary,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                TextFormField(
                  controller: _sequenceOrderController,
                  decoration: const InputDecoration(
                    labelText: 'Sequence Order *',
                    border: OutlineInputBorder(),
                    hintText: '1',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter sequence order';
                    }
                    if (int.tryParse(value) == null) {
                      return 'Please enter valid number';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _isLoading ? null : () => Navigator.pop(context),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _isLoading ? null : _saveStop,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppTheme.primaryColor,
            foregroundColor: Colors.white,
          ),
          child: _isLoading
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : Text(widget.stopData != null ? 'Update' : 'Add'),
        ),
      ],
    );
  }
}

