import 'package:busapp/config/api_config.dart';
import 'package:busapp/config/theme.dart';
import 'package:busapp/services/auth_service.dart';
import 'package:busapp/admin_login.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class OwnerDashboard extends StatefulWidget {
  final Function(int)? onNavigateToScreen;
  
  const OwnerDashboard({super.key, this.onNavigateToScreen});

  @override
  State<OwnerDashboard> createState() => _OwnerDashboardState();
}

class _OwnerDashboardState extends State<OwnerDashboard> {
  Map<String, dynamic>? _dashboardData;
  bool _isLoading = true;
  String? _error;
  Map<String, dynamic>? _userData;

  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadDashboard();
  }

  Future<void> _loadUserData() async {
    final userData = await AuthService.getUserData();
    if (mounted) {
      setState(() {
        _userData = userData;
      });
    }
  }

  Future<void> _loadDashboard() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.get(
        Uri.parse(ApiConfig.ownerDashboard),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _dashboardData = data;
          _isLoading = false;
        });
      } else if (response.statusCode == 401) {
        // Unauthorized - token expired or invalid
        await AuthService.logout();
        if (mounted) {
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => const AdminLogin()),
            (route) => false,
          );
        }
      } else {
        setState(() {
          _error = 'Failed to load dashboard: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Network error: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return _isLoading
        ? const Center(child: CircularProgressIndicator())
        : _error != null
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.error_outline,
                      size: 64,
                      color: AppTheme.dangerColor,
                    ),
                    const SizedBox(height: 16),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(
                        _error!,
                        style: const TextStyle(color: AppTheme.dangerColor),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: _loadDashboard,
                      child: const Text('RETRY'),
                    ),
                  ],
                ),
              )
            : RefreshIndicator(
                onRefresh: _loadDashboard,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Welcome Message
                      Text(
                        'Welcome back, ${_userData?['name'] ?? 'Owner'}! 👋',
                        style: Theme.of(context).textTheme.displayLarge,
                      ),
                      const SizedBox(height: 24),

                      // Stats Cards
                      if (_dashboardData != null)
                        _buildStatsCards()
                      else
                        const Center(
                          child: Padding(
                            padding: EdgeInsets.all(32),
                            child: Text('No dashboard data available'),
                          ),
                        ),

                      const SizedBox(height: 24),

                      // Revenue Summary Card
                      if (_dashboardData != null) _buildRevenueSummary(),
                    ],
                  ),
                ),
              );
  }

  Widget _buildStatsCards() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossAxisCount = constraints.maxWidth > 1200
            ? 4
            : constraints.maxWidth > 800
                ? 2
                : 1;

        return GridView.count(
          crossAxisCount: crossAxisCount,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: 2,
          children: [
            _buildStatCard(
              'Total Buses',
              (_dashboardData?['total_buses'] ?? 0).toString(),
              Icons.directions_bus,
              AppTheme.primaryColor,
              onTap: () => _navigateToScreen(1), // Navigate to Buses screen
            ),
            _buildStatCard(
              'Active Trips',
              (_dashboardData?['active_trips'] ?? _dashboardData?['active_buses'] ?? 0).toString(),
              Icons.trip_origin,
              AppTheme.secondaryColor,
              onTap: () => _navigateToScreen(1), // Navigate to Buses screen (filtered)
            ),
            _buildStatCard(
              'Pending Bookings',
              (_dashboardData?['pending_bookings'] ?? _dashboardData?['pending_requests'] ?? 0).toString(),
              Icons.pending_actions,
              AppTheme.warningColor,
              onTap: () => _navigateToScreen(3), // Navigate to Bookings screen
            ),
            _buildStatCard(
              "Today's Revenue",
              '৳${NumberFormat('#,##,###').format(_dashboardData?['today_revenue'] ?? 0)}',
              Icons.attach_money,
              AppTheme.secondaryColor,
              onTap: () => _navigateToScreen(5), // Navigate to Tickets screen
            ),
          ],
        );
      },
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color, {
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: color, size: 32),
                  const Spacer(),
                  Flexible(
                    child: Text(
                      value,
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                            color: color,
                            fontWeight: FontWeight.bold,
                          ),
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      title,
                      style: Theme.of(context).textTheme.bodyMedium,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                    ),
                  ),
                  if (onTap != null)
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 14,
                      color: color.withValues(alpha: 0.5),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  void _navigateToScreen(int index) {
    if (widget.onNavigateToScreen != null) {
      widget.onNavigateToScreen!(index);
    }
  }

  Widget _buildRevenueSummary() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Revenue Overview',
              style: Theme.of(context).textTheme.displaySmall,
            ),
            const SizedBox(height: 24),
            // Show total revenue summary
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Text(
                      'Total Revenue',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '৳${NumberFormat('#,##,###').format(_dashboardData?['total_revenue'] ?? 0)}',
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                            color: AppTheme.primaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    Text(
                      'Total Bookings',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      (_dashboardData?['total_bookings'] ?? 0).toString(),
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                            color: AppTheme.secondaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    Text(
                      'Confirmed',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      (_dashboardData?['confirmed_tickets'] ?? _dashboardData?['confirmed_bookings'] ?? 0).toString(),
                      style: Theme.of(context).textTheme.displayMedium?.copyWith(
                            color: AppTheme.secondaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
