import 'dart:async';
import 'package:busapp/config/api_config.dart';
import 'package:busapp/config/theme.dart';
import 'package:busapp/owner/bus_detail.dart';
import 'package:busapp/owner/add_edit_bus.dart';
import 'package:busapp/owner/add_edit_stop.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class BusManagementPage extends StatefulWidget {
  const BusManagementPage({super.key});

  @override
  State<BusManagementPage> createState() => _BusManagementPageState();
}

class _BusManagementPageState extends State<BusManagementPage> {
  List<dynamic> _buses = [];
  List<dynamic> _filteredBuses = [];
  bool _isLoading = true;
  String? _error;
  Timer? _refreshTimer;

  // Filters
  String _searchQuery = '';
  String _statusFilter = 'all';

  @override
  void initState() {
    super.initState();
    _loadBuses();

    // Auto-refresh every 10 seconds
    _refreshTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      if (mounted) {
        _loadBuses();
      }
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadBuses() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.get(
        Uri.parse(ApiConfig.ownerBuses),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _buses = data is List ? data : [];
          _isLoading = false;
        });
        _applyFilters();
      } else if (response.statusCode == 401) {
        // Token expired
        setState(() {
          _error = 'Session expired. Please login again.';
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Failed to load buses: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Network error: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _applyFilters() {
    setState(() {
      _filteredBuses = _buses.where((bus) {
        // Search filter
        if (_searchQuery.isNotEmpty) {
          final busNumber = (bus['bus_number'] ?? '').toString().toLowerCase();
          final routeFrom = (bus['route_from'] ?? '').toString().toLowerCase();
          final routeTo = (bus['route_to'] ?? '').toString().toLowerCase();
          final query = _searchQuery.toLowerCase();

          if (!busNumber.contains(query) &&
              !routeFrom.contains(query) &&
              !routeTo.contains(query)) {
            return false;
          }
        }

        // Status filter
        final isActive = bus['is_active'] == true;
        if (_statusFilter == 'active' && !isActive) {
          return false;
        }
        if (_statusFilter == 'inactive' && isActive) {
          return false;
        }

        return true;
      }).toList();
    });
  }

  Future<void> _toggleBusStatus(int busId, bool currentIsActive) async {
    try {
      final headers = await ApiConfig.getAuthHeaders();
      final newIsActive = !currentIsActive;
      
      final response = await http.put(
        Uri.parse(ApiConfig.bus(busId)),
        headers: headers,
        body: jsonEncode({'is_active': newIsActive}),
      );

      if (response.statusCode == 200) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Bus status updated to ${newIsActive ? "active" : "inactive"}'),
              backgroundColor: AppTheme.secondaryColor,
            ),
          );
        }
        _loadBuses();
      } else {
        final errorData = jsonDecode(response.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorData['detail'] ?? 'Failed to update status'),
              backgroundColor: AppTheme.dangerColor,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: AppTheme.dangerColor,
          ),
        );
      }
    }
  }

  Future<void> _deleteBus(int busId, String busNumber) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Bus'),
        content: Text('Are you sure you want to delete bus $busNumber? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.dangerColor,
            ),
            child: const Text('DELETE'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.delete(
        Uri.parse(ApiConfig.bus(busId)),
        headers: headers,
      );

      if (response.statusCode == 200 || response.statusCode == 204) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Bus deleted successfully'),
              backgroundColor: AppTheme.secondaryColor,
            ),
          );
        }
        _loadBuses();
      } else {
        final errorData = jsonDecode(response.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorData['detail'] ?? 'Failed to delete bus'),
              backgroundColor: AppTheme.dangerColor,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: AppTheme.dangerColor,
          ),
        );
      }
    }
  }

  String _formatBusType(String? type) {
    if (type == null) return 'Unknown';
    // Backend returns: "AC", "Non-AC", "AC Sleeper"
    final normalized = type.trim();
    if (normalized == 'AC' || normalized == 'Non-AC' || normalized == 'AC Sleeper') {
      return normalized;
    }
    // Handle legacy formats if any
    switch (normalized.toUpperCase()) {
      case 'NON_AC':
        return 'Non-AC';
      case 'AC_SLEEPER':
        return 'AC Sleeper';
      default:
        return normalized;
    }
  }

  String? _formatDepartureTime(String? timeStr) {
    if (timeStr == null) return null;
    try {
      final dateTime = DateTime.parse(timeStr);
      return DateFormat('MMM dd, yyyy - hh:mm a').format(dateTime);
    } catch (e) {
      return timeStr;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildFilters(),
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.error_outline,
                            size: 64,
                            color: AppTheme.dangerColor,
                          ),
                          const SizedBox(height: 16),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 32),
                            child: Text(
                              _error!,
                              style: const TextStyle(color: AppTheme.dangerColor),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: _loadBuses,
                            child: const Text('RETRY'),
                          ),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadBuses,
                      child: _filteredBuses.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.inbox,
                                    size: 64,
                                    color: Colors.grey[400],
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    _searchQuery.isNotEmpty || _statusFilter != 'all'
                                        ? 'No buses found matching your filters'
                                        : 'No buses found',
                                    style: TextStyle(color: Colors.grey[600]),
                                  ),
                                  if (_buses.isEmpty) ...[
                                    const SizedBox(height: 16),
                                    ElevatedButton.icon(
                                      onPressed: () async {
                                        final result = await Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) => const AddEditBusPage(),
                                          ),
                                        );
                                        if (result == true) {
                                          _loadBuses();
                                        }
                                      },
                                      icon: const Icon(Icons.add),
                                      label: const Text('Add First Bus'),
                                    ),
                                  ],
                                ],
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.all(16),
                              itemCount: _filteredBuses.length,
                              itemBuilder: (context, index) {
                                final bus = _filteredBuses[index];
                                return _buildBusCard(bus);
                              },
                            ),
                    ),
        ),
      ],
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withValues(alpha: 0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Search bar
          Expanded(
            flex: 2,
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search bus number or route...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                filled: true,
                fillColor: AppTheme.backgroundColor,
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
                _applyFilters();
              },
            ),
          ),
          const SizedBox(width: 12),

          // Status filter
          Expanded(
            child: DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'Status',
                border: const OutlineInputBorder(),
                filled: true,
                fillColor: AppTheme.backgroundColor,
              ),
              value: _statusFilter,
              items: const [
                DropdownMenuItem(value: 'all', child: Text('All Buses')),
                DropdownMenuItem(value: 'active', child: Text('Active Only')),
                DropdownMenuItem(value: 'inactive', child: Text('Inactive Only')),
              ],
              onChanged: (value) {
                setState(() {
                  _statusFilter = value!;
                });
                _applyFilters();
              },
            ),
          ),
          const SizedBox(width: 12),

          // Add Bus button
          ElevatedButton.icon(
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const AddEditBusPage(),
                ),
              );
              if (result == true) {
                _loadBuses();
              }
            },
            icon: const Icon(Icons.add),
            label: const Text('Add Bus'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: _loadBuses,
          ),
        ],
      ),
    );
  }

  Widget _buildBusCard(Map<String, dynamic> bus) {
    final busId = bus['id'] is int ? bus['id'] : int.tryParse(bus['id']?.toString() ?? '0') ?? 0;
    final busNumber = bus['bus_number'] ?? 'N/A';
    final routeFrom = bus['route_from'] ?? 'N/A';
    final routeTo = bus['route_to'] ?? 'N/A';
    final busType = _formatBusType(bus['bus_type']?.toString());
    final isActive = bus['is_active'] == true;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                // Bus icon
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.directions_bus,
                    color: AppTheme.primaryColor,
                    size: 32,
                  ),
                ),
                const SizedBox(width: 12),

                // Bus details
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              busNumber,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: AppTheme.textPrimary,
                              ),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: isActive
                                  ? AppTheme.secondaryColor.withValues(alpha: 0.1)
                                  : Colors.grey.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: isActive
                                    ? AppTheme.secondaryColor
                                    : Colors.grey,
                              ),
                            ),
                            child: Text(
                              isActive ? 'Active' : 'Inactive',
                              style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                                color: isActive
                                    ? AppTheme.secondaryColor
                                    : Colors.grey[700],
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '$routeFrom → $routeTo',
                        style: TextStyle(
                          fontSize: 14,
                          color: AppTheme.textSecondary,
                        ),
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                      ),
                    ],
                  ),
                ),

                // Status toggle
                Switch(
                  key: ValueKey('bus_toggle_$busId'),
                  value: isActive,
                  onChanged: (value) {
                    _toggleBusStatus(busId, isActive);
                  },
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Divider(),
            const SizedBox(height: 12),
            Wrap(
              spacing: 16,
              runSpacing: 8,
              children: [
                _buildInfoChip(
                  Icons.local_offer,
                  busType,
                  AppTheme.primaryColor,
                ),
                if (_formatDepartureTime(bus['departure_time']?.toString()) != null)
                  _buildInfoChip(
                    Icons.access_time,
                    _formatDepartureTime(bus['departure_time']?.toString())!,
                    AppTheme.warningColor,
                  ),
                if (bus['supervisor']?['name'] != null || bus['supervisor_name'] != null)
                  _buildInfoChip(
                    Icons.person,
                    bus['supervisor']?['name'] ?? bus['supervisor_name'] ?? 'N/A',
                    AppTheme.secondaryColor,
                  ),
                _buildInfoChip(
                  Icons.book,
                  '${bus['total_bookings'] ?? bus['bookings_count'] ?? 0} bookings',
                  Colors.purple,
                ),
                _buildInfoChip(
                  Icons.location_on,
                  '${bus['boarding_points_count'] ?? 0} stops',
                  Colors.orange,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () async {
                    final result = await showDialog(
                      context: context,
                      builder: (context) => AddEditStopDialog(busId: busId),
                    );
                    if (result == true) {
                      _loadBuses();
                    }
                  },
                  icon: const Icon(Icons.add_location, size: 18),
                  label: const Text('Add Stop'),
                ),
                const SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BusDetailPage(busId: busId),
                      ),
                    ).then((result) {
                      if (result == true) {
                        _loadBuses();
                      }
                    });
                  },
                  icon: const Icon(Icons.visibility, size: 18),
                  label: const Text('View'),
                ),
                const SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AddEditBusPage(busData: bus),
                      ),
                    );
                    if (result == true) {
                      _loadBuses();
                    }
                  },
                  icon: const Icon(Icons.edit, size: 18),
                  label: const Text('Edit'),
                ),
                const SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () => _deleteBus(busId, busNumber),
                  icon: const Icon(Icons.delete, size: 18),
                  label: const Text('Delete'),
                  style: TextButton.styleFrom(
                    foregroundColor: AppTheme.dangerColor,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Flexible(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: AppTheme.textSecondary,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ),
      ],
    );
  }
}
