import 'package:busapp/config/api_config.dart';
import 'package:busapp/owner/edit_supervisor.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SupervisorDetailPage extends StatefulWidget {
  final Map<String, dynamic> supervisor;
  
  const SupervisorDetailPage({
    super.key,
    required this.supervisor,
  });

  @override
  State<SupervisorDetailPage> createState() => _SupervisorDetailPageState();
}

class _SupervisorDetailPageState extends State<SupervisorDetailPage> {
  Map<String, dynamic>? _supervisorDetails;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _supervisorDetails = widget.supervisor;
    _loadSupervisorDetails();
  }

  Future<void> _loadSupervisorDetails() async {
    // Since there's no individual supervisor endpoint,
    // we'll use the data from the list
    // This can be enhanced when a GET /owner/supervisors/{id} endpoint is available
    setState(() {
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final supervisor = _supervisorDetails ?? widget.supervisor;
    final supervisorId = supervisor['id'] is int 
        ? supervisor['id'] 
        : int.tryParse(supervisor['id']?.toString() ?? '0') ?? 0;
    final assignedBuses = supervisor['assigned_buses'] as List<dynamic>? ?? [];

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Supervisor Details',
          style: TextStyle(
            color: Colors.black,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit, color: Colors.black),
            onPressed: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => EditSupervisorPage(supervisor: supervisor),
                ),
              );
              if (result == true && mounted) {
                Navigator.pop(context, true); // Refresh parent page
              }
            },
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, size: 64, color: Colors.red[400]),
                      const SizedBox(height: 16),
                      Text(
                        _error!,
                        style: TextStyle(color: Colors.red[600]),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _loadSupervisorDetails,
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Profile Card
                      Card(
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Row(
                            children: [
                              CircleAvatar(
                                radius: 40,
                                backgroundColor: Colors.purple[100],
                                child: Text(
                                  (supervisor['name']?[0] ?? 'S').toUpperCase(),
                                  style: TextStyle(
                                    fontSize: 32,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.purple[800],
                                  ),
                                ),
                              ),
                              const SizedBox(width: 20),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      supervisor['name'] ?? 'Unknown',
                                      style: const TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black87,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    Row(
                                      children: [
                                        Icon(Icons.phone, size: 16, color: Colors.grey[600]),
                                        const SizedBox(width: 4),
                                        Text(
                                          supervisor['phone'] ?? 'N/A',
                                          style: TextStyle(
                                            fontSize: 16,
                                            color: Colors.grey[700],
                                          ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 4,
                                      ),
                                      decoration: BoxDecoration(
                                        color: (supervisor['is_active'] ?? true)
                                            ? Colors.green[100]
                                            : Colors.red[100],
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Text(
                                        (supervisor['is_active'] ?? true) ? 'Active' : 'Inactive',
                                        style: TextStyle(
                                          color: (supervisor['is_active'] ?? true)
                                              ? Colors.green[800]
                                              : Colors.red[800],
                                          fontSize: 12,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Information Section
                      const Text(
                        'Information',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Card(
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            children: [
                              _buildInfoRow(
                                icon: Icons.badge,
                                label: 'Supervisor ID',
                                value: supervisorId.toString(),
                              ),
                              const Divider(),
                              _buildInfoRow(
                                icon: Icons.person,
                                label: 'Full Name',
                                value: supervisor['name'] ?? 'N/A',
                              ),
                              if (supervisor['nid'] != null) ...[
                                const Divider(),
                                _buildInfoRow(
                                  icon: Icons.credit_card,
                                  label: 'National ID (NID)',
                                  value: supervisor['nid']?.toString() ?? 'N/A',
                                ),
                              ],
                              const Divider(),
                              _buildInfoRow(
                                icon: Icons.phone,
                                label: 'Phone Number',
                                value: supervisor['phone'] ?? 'N/A',
                              ),
                              const Divider(),
                              _buildInfoRow(
                                icon: Icons.check_circle,
                                label: 'Status',
                                value: (supervisor['is_active'] ?? true) ? 'Active' : 'Inactive',
                                valueColor: (supervisor['is_active'] ?? true)
                                    ? Colors.green[700]
                                    : Colors.red[700],
                              ),
                            ],
                          ),
                        ),
                      ),
                      
                      const SizedBox(height: 20),
                      
                      // Assigned Buses Section
                      const Text(
                        'Assigned Buses',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 12),
                      assignedBuses.isEmpty
                          ? Card(
                              elevation: 2,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(32),
                                child: Center(
                                  child: Column(
                                    children: [
                                      Icon(Icons.directions_bus_outlined, 
                                          size: 64, color: Colors.grey[400]),
                                      const SizedBox(height: 16),
                                      Text(
                                        'No buses assigned',
                                        style: TextStyle(
                                          fontSize: 16,
                                          color: Colors.grey[600],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            )
                          : Card(
                              elevation: 2,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: ListView.separated(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                padding: const EdgeInsets.all(8),
                                itemCount: assignedBuses.length,
                                separatorBuilder: (context, index) => const Divider(),
                                itemBuilder: (context, index) {
                                  final bus = assignedBuses[index];
                                  return ListTile(
                                    leading: CircleAvatar(
                                      backgroundColor: Colors.blue[100],
                                      child: Icon(
                                        Icons.directions_bus,
                                        color: Colors.blue[800],
                                      ),
                                    ),
                                    title: Text(
                                      bus['bus_number'] ?? 'N/A',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    subtitle: Text(
                                      'Bus ID: ${bus['id'] ?? 'N/A'}',
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey[600],
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                    ],
                  ),
                ),
    );
  }

  Widget _buildInfoRow({
    required IconData icon,
    required String label,
    required String value,
    Color? valueColor,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.grey[600]),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: valueColor ?? Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

