import 'package:flutter/material.dart';
import 'package:busapp/config/theme.dart';
import 'package:busapp/services/auth_service.dart';
import 'package:busapp/admin_login.dart';
import 'package:busapp/owner/owner_dashboard.dart';
import 'package:busapp/owner/bus_management.dart';
import 'package:busapp/owner/supervisor_management.dart';
import 'package:busapp/owner/bookings_page.dart';
import 'package:busapp/owner/revenue_page.dart';
import 'package:busapp/owner/tickets_page.dart';
import 'package:busapp/owner/boarding_points_management.dart';
import 'package:busapp/owner/profile_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class MainLayout extends StatefulWidget {
  const MainLayout({super.key});

  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  int _selectedIndex = 0;
  Map<String, dynamic>? _userData;

  List<Widget> _buildScreens() {
    return [
      OwnerDashboard(
        onNavigateToScreen: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
      ),
      const BusManagementPage(),
      const SupervisorManagementPage(),
      const BookingsPage(),
      const RevenuePage(),
      const TicketsPage(),
      const BoardingPointsManagementPage(),
      const ProfileScreen(),
    ];
  }

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final userData = await AuthService.getUserData();
    if (mounted) {
      setState(() {
        _userData = userData;
      });
    }
  }

  Future<void> _handleLogout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.dangerColor,
            ),
            child: const Text('LOGOUT'),
          ),
        ],
      ),
    );

    if (shouldLogout == true && mounted) {
      await AuthService.logout();
      if (mounted) {
        Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => const AdminLogin()),
          (route) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          NavigationRail(
            selectedIndex: _selectedIndex,
            onDestinationSelected: (int index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            labelType: NavigationRailLabelType.all,
            backgroundColor: AppTheme.surfaceColor,
            selectedIconTheme: const IconThemeData(
              color: AppTheme.primaryColor,
              size: 28,
            ),
            unselectedIconTheme: IconThemeData(
              color: AppTheme.textSecondary,
              size: 24,
            ),
            selectedLabelTextStyle: const TextStyle(
              color: AppTheme.primaryColor,
              fontWeight: FontWeight.bold,
            ),
            unselectedLabelTextStyle: TextStyle(
              color: AppTheme.textSecondary,
            ),
            destinations: const [
              NavigationRailDestination(
                icon: Icon(Icons.dashboard_outlined),
                selectedIcon: Icon(Icons.dashboard),
                label: Text('Dashboard'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.directions_bus_outlined),
                selectedIcon: Icon(Icons.directions_bus),
                label: Text('Buses'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.supervisor_account_outlined),
                selectedIcon: Icon(Icons.supervisor_account),
                label: Text('Supervisors'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.book_online_outlined),
                selectedIcon: Icon(Icons.book_online),
                label: Text('Bookings'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.attach_money_outlined),
                selectedIcon: Icon(Icons.attach_money),
                label: Text('Revenue'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.confirmation_number_outlined),
                selectedIcon: Icon(Icons.confirmation_number),
                label: Text('Tickets'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.location_on_outlined),
                selectedIcon: Icon(Icons.location_on),
                label: Text('Boarding Points'),
              ),
              NavigationRailDestination(
                icon: Icon(Icons.person_outline),
                selectedIcon: Icon(Icons.person),
                label: Text('Profile'),
              ),
            ],
          ),
          const VerticalDivider(thickness: 1, width: 1),
          Expanded(
            child: Column(
              children: [
                // Top bar
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceColor,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withValues(alpha: 0.1),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Welcome, ${_userData?['name'] ?? 'Owner'}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.logout),
                        tooltip: 'Logout',
                        color: AppTheme.textSecondary,
                        onPressed: _handleLogout,
                      ),
                    ],
                  ),
                ),
                // Main content
                Expanded(
                  child: IndexedStack(
                    index: _selectedIndex,
                    children: _buildScreens(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

