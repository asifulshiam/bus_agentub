import 'package:busapp/config/api_config.dart';
import 'package:busapp/config/theme.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AddEditBusPage extends StatefulWidget {
  final Map<String, dynamic>? busData; // If provided, we're editing

  const AddEditBusPage({super.key, this.busData});

  @override
  State<AddEditBusPage> createState() => _AddEditBusPageState();
}

class _AddEditBusPageState extends State<AddEditBusPage> {
  final _formKey = GlobalKey<FormState>();
  final _busNumberController = TextEditingController();
  final _routeFromController = TextEditingController();
  final _routeToController = TextEditingController();
  final _fareController = TextEditingController();
  final _seatCapacityController = TextEditingController();
  final _departureTimeController = TextEditingController();

  String _selectedBusType = 'AC';
  bool _isLoading = false;
  DateTime? _selectedDateTime;
  
  // Supervisors
  List<dynamic> _supervisors = [];
  bool _loadingSupervisors = false;
  int? _selectedSupervisorId;

  /// Convert backend bus type to frontend format (normalize for dropdown)
  String _normalizeBusTypeForDisplay(String? busType) {
    if (busType == null) return 'AC';
    final normalized = busType.trim();
    // Backend returns: "AC", "Non-AC", "AC Sleeper"
    if (normalized == 'AC' || normalized == 'Non-AC' || normalized == 'AC Sleeper') {
      return normalized;
    }
    // Handle legacy formats if any
    if (normalized.toUpperCase() == 'NON_AC') return 'Non-AC';
    if (normalized.toUpperCase() == 'AC_SLEEPER') return 'AC Sleeper';
    return normalized;
  }

  @override
  void initState() {
    super.initState();
    _loadSupervisors();
    
    if (widget.busData != null) {
      // Editing existing bus
      _busNumberController.text = widget.busData!['bus_number'] ?? '';
      _routeFromController.text = widget.busData!['route_from'] ?? '';
      _routeToController.text = widget.busData!['route_to'] ?? '';
      _fareController.text = widget.busData!['fare']?.toString() ?? '';
      _seatCapacityController.text = widget.busData!['seat_capacity']?.toString() ?? '';
      
      // Set supervisor ID if exists
      if (widget.busData!['supervisor_id'] != null) {
        _selectedSupervisorId = widget.busData!['supervisor_id'] is int
            ? widget.busData!['supervisor_id']
            : int.tryParse(widget.busData!['supervisor_id']?.toString() ?? '');
      }
      
      _selectedBusType = _normalizeBusTypeForDisplay(widget.busData!['bus_type']?.toString());
      
      if (widget.busData!['departure_time'] != null) {
        try {
          _selectedDateTime = DateTime.parse(widget.busData!['departure_time']);
          _departureTimeController.text = _formatDateTime(_selectedDateTime!);
        } catch (e) {
          // Invalid date format
        }
      }
    }
  }

  Future<void> _loadSupervisors() async {
    setState(() {
      _loadingSupervisors = true;
    });

    try {
      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.get(
        Uri.parse(ApiConfig.ownerSupervisors),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _supervisors = data is List ? data : [];
          _loadingSupervisors = false;
        });
      } else {
        setState(() {
          _loadingSupervisors = false;
        });
      }
    } catch (e) {
      setState(() {
        _loadingSupervisors = false;
      });
    }
  }

  @override
  void dispose() {
    _busNumberController.dispose();
    _routeFromController.dispose();
    _routeToController.dispose();
    _fareController.dispose();
    _seatCapacityController.dispose();
    _departureTimeController.dispose();
    super.dispose();
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')} ${dateTime.hour.toString().padLeft(2, '0')}:${dateTime.minute.toString().padLeft(2, '0')}';
  }

  Future<void> _selectDateTime() async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDateTime ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );

    if (pickedDate != null) {
      final TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: _selectedDateTime != null
            ? TimeOfDay.fromDateTime(_selectedDateTime!)
            : TimeOfDay.now(),
      );

      if (pickedTime != null) {
        setState(() {
          _selectedDateTime = DateTime(
            pickedDate.year,
            pickedDate.month,
            pickedDate.day,
            pickedTime.hour,
            pickedTime.minute,
          );
          _departureTimeController.text = _formatDateTime(_selectedDateTime!);
        });
      }
    }
  }

  Future<void> _saveBus() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    if (_selectedDateTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select departure time')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final headers = await ApiConfig.getAuthHeaders();
      final body = {
        'bus_number': _busNumberController.text.trim(),
        'route_from': _routeFromController.text.trim(),
        'route_to': _routeToController.text.trim(),
        'bus_type': _selectedBusType,
        'fare': double.tryParse(_fareController.text) ?? 0,
        'seat_capacity': int.tryParse(_seatCapacityController.text) ?? 40,
        'departure_time': _selectedDateTime!.toIso8601String(),
        if (_selectedSupervisorId != null) 'supervisor_id': _selectedSupervisorId,
      };

      final response = widget.busData != null
          ? await http.put(
              Uri.parse(ApiConfig.bus(widget.busData!['id'])),
              headers: headers,
              body: jsonEncode(body),
            )
          : await http.post(
              Uri.parse(ApiConfig.buses),
              headers: headers,
              body: jsonEncode(body),
            );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(widget.busData != null
                  ? 'Bus updated successfully'
                  : 'Bus created successfully'),
              backgroundColor: AppTheme.secondaryColor,
            ),
          );
          Navigator.pop(context, true); // Return true to indicate success
        }
      } else {
        final errorData = jsonDecode(response.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorData['detail'] ?? 'Failed to save bus'),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: ${e.toString()}')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceColor,
        elevation: 1,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: AppTheme.textPrimary),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          widget.busData != null ? 'Edit Bus' : 'Add New Bus',
          style: const TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [
          if (_isLoading)
            const Padding(
              padding: EdgeInsets.all(16.0),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            )
          else
            TextButton(
              onPressed: _saveBus,
              child: const Text(
                'Save',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      TextFormField(
                        controller: _busNumberController,
                        decoration: const InputDecoration(
                          labelText: 'Bus Number *',
                          border: OutlineInputBorder(),
                          hintText: 'e.g., DHA-1234',
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter bus number';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _routeFromController,
                              decoration: const InputDecoration(
                                labelText: 'Route From *',
                                border: OutlineInputBorder(),
                                hintText: 'e.g., Dhaka',
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter origin';
                                }
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: TextFormField(
                              controller: _routeToController,
                              decoration: const InputDecoration(
                                labelText: 'Route To *',
                                border: OutlineInputBorder(),
                                hintText: 'e.g., Chittagong',
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter destination';
                                }
                                return null;
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: _selectedBusType,
                        decoration: const InputDecoration(
                          labelText: 'Bus Type *',
                          border: OutlineInputBorder(),
                        ),
                        items: const [
                          DropdownMenuItem(value: 'AC', child: Text('AC')),
                          DropdownMenuItem(value: 'Non-AC', child: Text('Non-AC')),
                          DropdownMenuItem(
                              value: 'AC Sleeper', child: Text('AC Sleeper')),
                        ],
                        onChanged: (value) {
                          if (value != null) {
                            setState(() {
                              _selectedBusType = value;
                            });
                          }
                        },
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              controller: _fareController,
                              decoration: const InputDecoration(
                                labelText: 'Fare (BDT) *',
                                border: OutlineInputBorder(),
                                hintText: '850',
                              ),
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter fare';
                                }
                                if (double.tryParse(value) == null) {
                                  return 'Please enter valid number';
                                }
                                return null;
                              },
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: TextFormField(
                              controller: _seatCapacityController,
                              decoration: const InputDecoration(
                                labelText: 'Seat Capacity *',
                                border: OutlineInputBorder(),
                                hintText: '40',
                              ),
                              keyboardType: TextInputType.number,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter capacity';
                                }
                                if (int.tryParse(value) == null) {
                                  return 'Please enter valid number';
                                }
                                return null;
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _departureTimeController,
                        decoration: const InputDecoration(
                          labelText: 'Departure Time *',
                          border: OutlineInputBorder(),
                          hintText: 'Select date and time',
                        ),
                        readOnly: true,
                        onTap: _selectDateTime,
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please select departure time';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 16),
                      _loadingSupervisors
                          ? const Padding(
                              padding: EdgeInsets.all(16.0),
                              child: Center(
                                child: CircularProgressIndicator(),
                              ),
                            )
                          : DropdownButtonFormField<int?>(
                              value: _selectedSupervisorId,
                              decoration: const InputDecoration(
                                labelText: 'Supervisor (Optional)',
                                border: OutlineInputBorder(),
                                helperText: 'Select a supervisor for this bus',
                              ),
                              items: [
                                const DropdownMenuItem<int?>(
                                  value: null,
                                  child: Text('No Supervisor'),
                                ),
                                ..._supervisors
                                    .map((supervisor) {
                                      final id = supervisor['id'] is int
                                          ? supervisor['id']
                                          : int.tryParse(supervisor['id']?.toString() ?? '');
                                      if (id == null) return null;
                                      
                                      final name = supervisor['name'] ?? 'Unknown';
                                      final phone = supervisor['phone'] ?? '';
                                      
                                      return DropdownMenuItem<int?>(
                                        value: id,
                                        child: Text('$name ($phone)'),
                                      );
                                    })
                                    .where((item) => item != null)
                                    .cast<DropdownMenuItem<int?>>(),
                              ],
                              onChanged: (value) {
                                setState(() {
                                  _selectedSupervisorId = value;
                                });
                              },
                              validator: (value) {
                                // Supervisor is optional, so no validation needed
                                return null;
                              },
                            ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveBus,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : Text(
                          widget.busData != null ? 'Update Bus' : 'Create Bus',
                          style: const TextStyle(fontSize: 16),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

