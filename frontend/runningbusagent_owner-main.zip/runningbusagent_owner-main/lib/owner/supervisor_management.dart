import 'package:busapp/config/api_config.dart';
import 'package:busapp/config/theme.dart';
import 'package:busapp/owner/supervisor_detail.dart';
import 'package:busapp/owner/edit_supervisor.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SupervisorManagementPage extends StatefulWidget {
  const SupervisorManagementPage({super.key});

  @override
  State<SupervisorManagementPage> createState() => _SupervisorManagementPageState();
}

class _SupervisorManagementPageState extends State<SupervisorManagementPage> {
  List<dynamic> _supervisors = [];
  List<dynamic> _filteredSupervisors = [];
  bool _isLoading = true;
  String? _error;

  // Filters
  String _searchQuery = '';
  String _statusFilter = 'all';

  @override
  void initState() {
    super.initState();
    _loadSupervisors();
  }

  Future<void> _loadSupervisors() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.get(
        Uri.parse(ApiConfig.ownerSupervisors),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _supervisors = data is List ? data : [];
          _isLoading = false;
        });
        _applyFilters();
      } else if (response.statusCode == 401) {
        setState(() {
          _error = 'Session expired. Please login again.';
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Failed to load supervisors: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Network error: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _applyFilters() {
    setState(() {
      _filteredSupervisors = _supervisors.where((supervisor) {
        // Search filter
        if (_searchQuery.isNotEmpty) {
          final name = (supervisor['name'] ?? '').toString().toLowerCase();
          final phone = (supervisor['phone'] ?? '').toString().toLowerCase();
          final nid = (supervisor['nid'] ?? '').toString().toLowerCase();
          final query = _searchQuery.toLowerCase();

          if (!name.contains(query) &&
              !phone.contains(query) &&
              !nid.contains(query)) {
            return false;
          }
        }

        // Status filter
        final isActive = supervisor['is_active'] ?? true;
        if (_statusFilter == 'active' && !isActive) {
          return false;
        }
        if (_statusFilter == 'inactive' && isActive) {
          return false;
        }

        return true;
      }).toList();
    });
  }

  Future<void> _showAddSupervisorDialog() async {
    final nameController = TextEditingController();
    final nidController = TextEditingController();
    final phoneController = TextEditingController(text: '+880');
    final passwordController = TextEditingController();
    final _formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Register New Supervisor'),
        content: SizedBox(
          width: MediaQuery.of(context).size.width * 0.8,
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: 'Full Name *',
                      border: OutlineInputBorder(),
                      hintText: 'John Doe',
                      prefixIcon: Icon(Icons.person),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter name';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: nidController,
                    decoration: const InputDecoration(
                      labelText: 'National ID (NID) *',
                      border: OutlineInputBorder(),
                      hintText: '1234567890123',
                      prefixIcon: Icon(Icons.badge),
                    ),
                    keyboardType: TextInputType.number,
                    maxLength: 17,
                    buildCounter: (context, {required currentLength, required isFocused, maxLength}) => null,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter NID';
                      }
                      if (value.length > 17) {
                        return 'NID should be maximum 17 digits';
                      }
                      if (!RegExp(r'^[0-9]+$').hasMatch(value)) {
                        return 'NID should contain only digits';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: phoneController,
                    decoration: const InputDecoration(
                      labelText: 'Phone Number *',
                      border: OutlineInputBorder(),
                      hintText: '+8801712345678',
                      prefixIcon: Icon(Icons.phone),
                      helperText: 'Format: +880 followed by 10 digits',
                    ),
                    keyboardType: TextInputType.phone,
                    maxLength: 14, // +880 + 11 digits = 14 chars max, but we allow only 11 digits after +880
                    buildCounter: (context, {required currentLength, required isFocused, maxLength}) => null,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter phone number';
                      }
                      // Check if starts with +880
                      if (!value.startsWith('+880')) {
                        return 'Phone must start with +880';
                      }
                      // Extract digits after +880 (should be max 11 digits)
                      final digitsAfterPrefix = value.substring(4);
                      if (digitsAfterPrefix.length > 11) {
                        return 'Phone number should be max 11 digits after +880';
                      }
                      if (digitsAfterPrefix.length < 10) {
                        return 'Phone number should be at least 10 digits after +880';
                      }
                      if (!RegExp(r'^[0-9]+$').hasMatch(digitsAfterPrefix)) {
                        return 'Phone number should contain only digits after +880';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: passwordController,
                    decoration: const InputDecoration(
                      labelText: 'Password *',
                      border: OutlineInputBorder(),
                      hintText: 'SecurePass123',
                      prefixIcon: Icon(Icons.lock),
                      helperText: '6-10 characters',
                    ),
                    obscureText: true,
                    maxLength: 10,
                    buildCounter: (context, {required currentLength, required isFocused, maxLength}) => null,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter password';
                      }
                      if (value.length < 6) {
                        return 'Password must be at least 6 characters';
                      }
                      if (value.length > 10) {
                        return 'Password must be maximum 10 characters';
                      }
                      return null;
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          ElevatedButton(
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                Navigator.pop(context, true);
              }
            },
            child: const Text('REGISTER'),
          ),
        ],
      ),
    );

    if (result != true) return;

    try {
      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.post(
        Uri.parse(ApiConfig.registerSupervisor),
        headers: headers,
        body: jsonEncode({
          'name': nameController.text.trim(),
          'nid': nidController.text.trim(),
          'phone': phoneController.text.trim(),
          'password': passwordController.text,
          'role': 'passenger',
        }),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Supervisor registered successfully'),
              backgroundColor: AppTheme.secondaryColor,
            ),
          );
        }
        _loadSupervisors();
      } else {
        final errorData = jsonDecode(response.body);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(errorData['detail'] ?? 'Failed to register supervisor'),
              backgroundColor: AppTheme.dangerColor,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: ${e.toString()}'),
            backgroundColor: AppTheme.dangerColor,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildFilters(),
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.error_outline,
                            size: 64,
                            color: AppTheme.dangerColor,
                          ),
                          const SizedBox(height: 16),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 32),
                            child: Text(
                              _error!,
                              style: const TextStyle(color: AppTheme.dangerColor),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: _loadSupervisors,
                            child: const Text('RETRY'),
                          ),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadSupervisors,
                      child: _filteredSupervisors.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.inbox,
                                    size: 64,
                                    color: Colors.grey[400],
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    _searchQuery.isNotEmpty || _statusFilter != 'all'
                                        ? 'No supervisors found matching your filters'
                                        : 'No supervisors found',
                                    style: TextStyle(color: Colors.grey[600]),
                                  ),
                                  if (_supervisors.isEmpty) ...[
                                    const SizedBox(height: 16),
                                    ElevatedButton.icon(
                                      onPressed: _showAddSupervisorDialog,
                                      icon: const Icon(Icons.person_add),
                                      label: const Text('Register First Supervisor'),
                                    ),
                                  ],
                                ],
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.all(16),
                              itemCount: _filteredSupervisors.length,
                              itemBuilder: (context, index) {
                                final supervisor = _filteredSupervisors[index];
                                return _buildSupervisorCard(supervisor);
                              },
                            ),
                    ),
        ),
      ],
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withValues(alpha: 0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Search bar
          Expanded(
            flex: 2,
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search by name, phone, or NID...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                filled: true,
                fillColor: AppTheme.backgroundColor,
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
                _applyFilters();
              },
            ),
          ),
          const SizedBox(width: 12),

          // Status filter
          Expanded(
            child: DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: 'Status',
                border: const OutlineInputBorder(),
                filled: true,
                fillColor: AppTheme.backgroundColor,
              ),
              value: _statusFilter,
              items: const [
                DropdownMenuItem(value: 'all', child: Text('All Supervisors')),
                DropdownMenuItem(value: 'active', child: Text('Active Only')),
                DropdownMenuItem(value: 'inactive', child: Text('Inactive Only')),
              ],
              onChanged: (value) {
                setState(() {
                  _statusFilter = value!;
                });
                _applyFilters();
              },
            ),
          ),
          const SizedBox(width: 12),

          // Add Supervisor button
          ElevatedButton.icon(
            onPressed: _showAddSupervisorDialog,
            icon: const Icon(Icons.person_add),
            label: const Text('Register'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Refresh',
            onPressed: _loadSupervisors,
          ),
        ],
      ),
    );
  }

  Widget _buildSupervisorCard(Map<String, dynamic> supervisor) {
    final assignedBuses = supervisor['assigned_buses'] as List<dynamic>? ?? [];
    final isActive = supervisor['is_active'] ?? true;
    final name = supervisor['name'] ?? 'Unknown';
    final initial = name.isNotEmpty ? name[0].toUpperCase() : 'S';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: AppTheme.primaryColor.withValues(alpha: 0.1),
                  child: Text(
                    initial,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryColor,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              name,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: isActive
                                  ? AppTheme.secondaryColor.withValues(alpha: 0.1)
                                  : Colors.grey.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: isActive
                                    ? AppTheme.secondaryColor
                                    : Colors.grey,
                              ),
                            ),
                            child: Text(
                              isActive ? 'Active' : 'Inactive',
                              style: TextStyle(
                                color: isActive
                                    ? AppTheme.secondaryColor
                                    : Colors.grey[700],
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Wrap(
                        spacing: 16,
                        runSpacing: 8,
                        children: [
                          _buildInfoChip(
                            Icons.phone,
                            supervisor['phone'] ?? 'N/A',
                            AppTheme.primaryColor,
                          ),
                          if (supervisor['nid'] != null)
                            _buildInfoChip(
                              Icons.badge,
                              'NID: ${supervisor['nid']}',
                              AppTheme.warningColor,
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            if (assignedBuses.isNotEmpty) ...[
              const SizedBox(height: 12),
              const Divider(),
              const SizedBox(height: 12),
              Row(
                children: [
                  Icon(
                    Icons.directions_bus,
                    size: 16,
                    color: AppTheme.textSecondary,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '${assignedBuses.length} bus${assignedBuses.length > 1 ? 'es' : ''} assigned',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ],
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SupervisorDetailPage(
                          supervisor: supervisor,
                        ),
                      ),
                    ).then((result) {
                      if (result == true) {
                        _loadSupervisors();
                      }
                    });
                  },
                  icon: const Icon(Icons.visibility, size: 18),
                  label: const Text('View'),
                ),
                const SizedBox(width: 8),
                TextButton.icon(
                  onPressed: () async {
                    final result = await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => EditSupervisorPage(
                          supervisor: supervisor,
                        ),
                      ),
                    );
                    if (result == true) {
                      _loadSupervisors();
                    }
                  },
                  icon: const Icon(Icons.edit, size: 18),
                  label: const Text('Edit'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Flexible(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: AppTheme.textSecondary,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ),
      ],
    );
  }
}
