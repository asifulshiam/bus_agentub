import 'package:busapp/config/api_config.dart';
import 'package:busapp/config/theme.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';

class BookingsPage extends StatefulWidget {
  const BookingsPage({super.key});

  @override
  State<BookingsPage> createState() => _BookingsPageState();
}

class _BookingsPageState extends State<BookingsPage> {
  List<dynamic> _bookings = [];
  List<dynamic> _filteredBookings = [];
  bool _isLoading = true;
  String? _error;

  // Filters
  String _statusFilter = 'all';
  int? _selectedBusId;
  String _searchQuery = '';
  List<Map<String, dynamic>> _availableBuses = [];

  @override
  void initState() {
    super.initState();
    _loadBookings();
  }

  Future<void> _loadBookings() async {
    try {
      setState(() {
        _isLoading = true;
        _error = null;
      });

      final headers = await ApiConfig.getAuthHeaders();
      final response = await http.get(
        Uri.parse(ApiConfig.ownerBookings),
        headers: headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _bookings = data is List ? data : [];
          _isLoading = false;
        });
        _extractAvailableBuses();
        _applyFilters();
      } else if (response.statusCode == 401) {
        setState(() {
          _error = 'Session expired. Please login again.';
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Failed to load bookings: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Network error: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  void _extractAvailableBuses() {
    final buses = <int, Map<String, dynamic>>{};
    for (var booking in _bookings) {
      final busId = booking['bus_id'];
      if (busId != null && !buses.containsKey(busId)) {
        buses[busId] = {
          'bus_id': busId,
          'bus_number': booking['bus_number'] ?? 'Bus #$busId',
        };
      }
    }
    setState(() {
      _availableBuses = buses.values.toList();
    });
  }

  void _applyFilters() {
    setState(() {
      _filteredBookings = _bookings.where((booking) {
        // Status filter
        if (_statusFilter != 'all' && booking['status']?.toString().toLowerCase() != _statusFilter.toLowerCase()) {
          return false;
        }

        // Bus filter
        if (_selectedBusId != null && booking['bus_id'] != _selectedBusId) {
          return false;
        }

        // Search filter (passenger name or phone)
        if (_searchQuery.isNotEmpty) {
          final passengerName = (booking['passenger_name'] ?? '').toString().toLowerCase();
          final passengerPhone = (booking['passenger_phone'] ?? '').toString().toLowerCase();
          final bookingId = (booking['booking_id'] ?? booking['id'] ?? '').toString().toLowerCase();
          final query = _searchQuery.toLowerCase();

          if (!passengerName.contains(query) &&
              !passengerPhone.contains(query) &&
              !bookingId.contains(query)) {
            return false;
          }
        }

        return true;
      }).toList();
    });
  }

  Map<String, int> _getStatusCounts() {
    return {
      'all': _bookings.length,
      'pending': _bookings.where((b) => (b['status'] ?? '').toString().toLowerCase() == 'pending').length,
      'accepted': _bookings.where((b) => (b['status'] ?? '').toString().toLowerCase() == 'accepted').length,
      'confirmed': _bookings.where((b) => (b['status'] ?? '').toString().toLowerCase() == 'confirmed').length,
      'rejected': _bookings.where((b) => (b['status'] ?? '').toString().toLowerCase() == 'rejected').length,
    };
  }

  double _calculateTotalRevenue() {
    return _filteredBookings
        .where((b) => ['accepted', 'confirmed'].contains((b['status'] ?? '').toString().toLowerCase()))
        .fold(0.0, (sum, b) => sum + ((b['total_fare'] ?? b['fare'] ?? 0) as num).toDouble());
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _buildFilters(),
        _buildTabs(),
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.error_outline,
                            size: 64,
                            color: AppTheme.dangerColor,
                          ),
                          const SizedBox(height: 16),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 32),
                            child: Text(
                              _error!,
                              style: const TextStyle(color: AppTheme.dangerColor),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: _loadBookings,
                            child: const Text('RETRY'),
                          ),
                        ],
                      ),
                    )
                  : RefreshIndicator(
                      onRefresh: _loadBookings,
                      child: _filteredBookings.isEmpty
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.inbox,
                                    size: 64,
                                    color: Colors.grey[400],
                                  ),
                                  const SizedBox(height: 16),
                                  Text(
                                    _searchQuery.isNotEmpty || _statusFilter != 'all' || _selectedBusId != null
                                        ? 'No bookings found matching your filters'
                                        : 'No bookings found',
                                    style: TextStyle(color: Colors.grey[600]),
                                  ),
                                ],
                              ),
                            )
                          : ListView.builder(
                              padding: const EdgeInsets.all(16),
                              itemCount: _filteredBookings.length,
                              itemBuilder: (context, index) {
                                final booking = _filteredBookings[index];
                                return _buildBookingCard(booking);
                              },
                            ),
                    ),
        ),
        _buildSummary(),
      ],
    );
  }

  Widget _buildFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withValues(alpha: 0.1),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Search bar
          TextField(
            decoration: InputDecoration(
              hintText: 'Search passenger name, phone, or booking ID...',
              prefixIcon: const Icon(Icons.search),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(8),
              ),
              filled: true,
              fillColor: AppTheme.backgroundColor,
            ),
            onChanged: (value) {
              setState(() {
                _searchQuery = value;
              });
              _applyFilters();
            },
          ),
          const SizedBox(height: 12),

          // Filter dropdowns
          Row(
            children: [
              // Status filter
              Expanded(
                child: DropdownButtonFormField<String>(
                  decoration: InputDecoration(
                    labelText: 'Status',
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: AppTheme.backgroundColor,
                  ),
                  value: _statusFilter,
                  items: const [
                    DropdownMenuItem(value: 'all', child: Text('All Status')),
                    DropdownMenuItem(value: 'pending', child: Text('Pending')),
                    DropdownMenuItem(value: 'accepted', child: Text('Accepted')),
                    DropdownMenuItem(value: 'confirmed', child: Text('Confirmed')),
                    DropdownMenuItem(value: 'rejected', child: Text('Rejected')),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _statusFilter = value!;
                    });
                    _applyFilters();
                  },
                ),
              ),
              const SizedBox(width: 12),

              // Bus filter
              Expanded(
                child: DropdownButtonFormField<int?>(
                  decoration: InputDecoration(
                    labelText: 'Bus',
                    border: const OutlineInputBorder(),
                    filled: true,
                    fillColor: AppTheme.backgroundColor,
                  ),
                  value: _selectedBusId,
                  items: [
                    const DropdownMenuItem(value: null, child: Text('All Buses')),
                    ..._availableBuses.map<DropdownMenuItem<int?>>((bus) {
                      return DropdownMenuItem<int?>(
                        value: bus['bus_id'] as int?,
                        child: Text(bus['bus_number'] as String),
                      );
                    }),
                  ],
                  onChanged: (value) {
                    setState(() {
                      _selectedBusId = value;
                    });
                    _applyFilters();
                  },
                ),
              ),
              const SizedBox(width: 12),
              IconButton(
                icon: const Icon(Icons.refresh),
                tooltip: 'Refresh',
                onPressed: _loadBookings,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabs() {
    final counts = _getStatusCounts();

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        border: Border(
          bottom: BorderSide(color: Colors.grey.withValues(alpha: 0.2)),
        ),
      ),
      child: Row(
        children: [
          _buildTab('All', 'all', counts['all']!),
          _buildTab('Pending', 'pending', counts['pending']!),
          _buildTab('Accepted', 'accepted', counts['accepted']!),
          _buildTab('Confirmed', 'confirmed', counts['confirmed']!),
          _buildTab('Rejected', 'rejected', counts['rejected']!),
        ],
      ),
    );
  }

  Widget _buildTab(String label, String status, int count) {
    final isSelected = _statusFilter == status;

    return Expanded(
      child: InkWell(
        onTap: () {
          setState(() {
            _statusFilter = status;
          });
          _applyFilters();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: isSelected ? AppTheme.primaryColor : Colors.transparent,
                width: 2,
              ),
            ),
          ),
          child: Column(
            children: [
              Text(
                label,
                style: TextStyle(
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                  color: isSelected ? AppTheme.primaryColor : AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '($count)',
                style: TextStyle(
                  fontSize: 12,
                  color: isSelected ? AppTheme.primaryColor : Colors.grey[500],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBookingCard(Map<String, dynamic> booking) {
    final status = (booking['status'] ?? 'unknown').toString().toLowerCase();
    final statusColor = _getStatusColor(status);
    final bookingId = booking['booking_id'] ?? booking['id'] ?? 'N/A';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    'Booking #$bookingId',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.textPrimary,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: statusColor),
                  ),
                  child: Text(
                    status.toUpperCase(),
                    style: TextStyle(
                      color: statusColor,
                      fontWeight: FontWeight.w600,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Divider(),
            const SizedBox(height: 12),
            Wrap(
              spacing: 16,
              runSpacing: 8,
              children: [
                if (booking['bus_number'] != null)
                  _buildInfoChip(
                    Icons.directions_bus,
                    booking['bus_number'].toString(),
                    AppTheme.primaryColor,
                  ),
                if (booking['route_from'] != null && booking['route_to'] != null)
                  _buildInfoChip(
                    Icons.route,
                    '${booking['route_from']} → ${booking['route_to']}',
                    AppTheme.secondaryColor,
                  ),
                if (booking['passenger_name'] != null)
                  _buildInfoChip(
                    Icons.person,
                    booking['passenger_name'].toString(),
                    Colors.purple,
                  ),
                if (booking['passenger_phone'] != null)
                  _buildInfoChip(
                    Icons.phone,
                    booking['passenger_phone'].toString(),
                    Colors.blue,
                  ),
                if (booking['seats_booked'] != null)
                  _buildInfoChip(
                    Icons.event_seat,
                    '${booking['seats_booked']} seats',
                    Colors.orange,
                  ),
                if (booking['request_time'] != null)
                  _buildInfoChip(
                    Icons.access_time,
                    _formatDateTime(booking['request_time'].toString()),
                    AppTheme.warningColor,
                  ),
              ],
            ),
            if (booking['total_fare'] != null || booking['fare'] != null) ...[
              const SizedBox(height: 12),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    'Total: ৳${(booking['total_fare'] ?? booking['fare'] ?? 0).toString()}',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.secondaryColor,
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String label, Color color) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: color),
        const SizedBox(width: 4),
        Flexible(
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: AppTheme.textSecondary,
            ),
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ),
      ],
    );
  }

  Widget _buildSummary() {
    final counts = _getStatusCounts();
    final totalRevenue = _calculateTotalRevenue();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.backgroundColor,
        border: Border(
          top: BorderSide(color: Colors.grey.withValues(alpha: 0.2)),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildSummaryItem('Total', '${counts['all']}', AppTheme.primaryColor),
          _buildSummaryItem('Pending', '${counts['pending']}', AppTheme.warningColor),
          _buildSummaryItem('Accepted', '${counts['accepted']}', AppTheme.secondaryColor),
          _buildSummaryItem('Confirmed', '${counts['confirmed']}', Colors.green),
          _buildSummaryItem(
            'Revenue',
            '৳${NumberFormat('#,##,###').format(totalRevenue)}',
            Colors.purple,
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending':
        return AppTheme.warningColor;
      case 'accepted':
        return AppTheme.secondaryColor;
      case 'confirmed':
        return Colors.green;
      case 'rejected':
        return AppTheme.dangerColor;
      default:
        return Colors.grey;
    }
  }

  String _formatDateTime(String? timestamp) {
    if (timestamp == null || timestamp.isEmpty) return 'N/A';
    try {
      final dt = DateTime.parse(timestamp);
      return DateFormat('MMM dd, yyyy - hh:mm a').format(dt);
    } catch (e) {
      return timestamp;
    }
  }
}
