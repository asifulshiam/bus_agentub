import 'package:busapp/config/theme.dart';
import 'package:busapp/services/boarding_points_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class BoardingPointsManagementPage extends StatefulWidget {
  const BoardingPointsManagementPage({super.key});

  @override
  State<BoardingPointsManagementPage> createState() => _BoardingPointsManagementPageState();
}

class _BoardingPointsManagementPageState extends State<BoardingPointsManagementPage> {
  List<BoardingPoint> _boardingPoints = [];
  List<BoardingPoint> _filteredPoints = [];
  bool _isLoading = true;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _loadBoardingPoints();
  }

  Future<void> _loadBoardingPoints() async {
    setState(() {
      _isLoading = true;
    });

    final points = await BoardingPointsService.getAll();
    
    setState(() {
      _boardingPoints = points;
      _applyFilter();
      _isLoading = false;
    });
  }

  void _applyFilter() {
    if (_searchQuery.isEmpty) {
      setState(() {
        _filteredPoints = List.from(_boardingPoints);
      });
    } else {
      BoardingPointsService.search(_searchQuery).then((results) {
        setState(() {
          _filteredPoints = results;
        });
      });
    }
  }

  Future<void> _showAddEditDialog({BoardingPoint? point}) async {
    final nameController = TextEditingController(text: point?.name ?? '');
    final latController = TextEditingController(text: point?.lat.toString() ?? '');
    final lngController = TextEditingController(text: point?.lng.toString() ?? '');
    final formKey = GlobalKey<FormState>();

    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(point == null ? 'Add Boarding Point' : 'Edit Boarding Point'),
        content: SizedBox(
          width: MediaQuery.of(context).size.width * 0.8,
          child: SingleChildScrollView(
            child: Form(
              key: formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: 'Name *',
                      border: OutlineInputBorder(),
                      hintText: 'e.g., Mohakhali Bus Stand',
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter name';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: latController,
                          decoration: const InputDecoration(
                            labelText: 'Latitude *',
                            border: OutlineInputBorder(),
                            hintText: '23.7808',
                          ),
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Required';
                            }
                            if (double.tryParse(value) == null) {
                              return 'Invalid number';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: TextFormField(
                          controller: lngController,
                          decoration: const InputDecoration(
                            labelText: 'Longitude *',
                            border: OutlineInputBorder(),
                            hintText: '90.4044',
                          ),
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Required';
                            }
                            if (double.tryParse(value) == null) {
                              return 'Invalid number';
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          ElevatedButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.pop(context, true);
              }
            },
            child: Text(point == null ? 'ADD' : 'UPDATE'),
          ),
        ],
      ),
    );

    if (result == true) {
      final newPoint = BoardingPoint(
        id: point?.id ?? BoardingPointsService.generateId(),
        name: nameController.text.trim(),
        lat: double.parse(latController.text),
        lng: double.parse(lngController.text),
        createdAt: point?.createdAt ?? DateTime.now(),
      );

      final success = point == null
          ? await BoardingPointsService.add(newPoint)
          : await BoardingPointsService.update(newPoint);

      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(point == null
                ? 'Boarding point added successfully'
                : 'Boarding point updated successfully'),
            backgroundColor: AppTheme.secondaryColor,
          ),
        );
        _loadBoardingPoints();
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to save boarding point'),
            backgroundColor: AppTheme.dangerColor,
          ),
        );
      }
    }
  }

  Future<void> _deletePoint(BoardingPoint point) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Boarding Point'),
        content: Text('Are you sure you want to delete "${point.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('CANCEL'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.dangerColor,
            ),
            child: const Text('DELETE'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final success = await BoardingPointsService.delete(point.id);
      if (success && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Boarding point deleted successfully'),
            backgroundColor: AppTheme.secondaryColor,
          ),
        );
        _loadBoardingPoints();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Search and Add Button
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.surfaceColor,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withValues(alpha: 0.1),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Search boarding points...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    filled: true,
                    fillColor: AppTheme.backgroundColor,
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                    _applyFilter();
                  },
                ),
              ),
              const SizedBox(width: 12),
              ElevatedButton.icon(
                onPressed: () => _showAddEditDialog(),
                icon: const Icon(Icons.add),
                label: const Text('Add Point'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.primaryColor,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
              ),
            ],
          ),
        ),

        // List
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _filteredPoints.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.location_off,
                            size: 64,
                            color: Colors.grey[400],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            _searchQuery.isNotEmpty
                                ? 'No boarding points found'
                                : 'No boarding points added yet',
                            style: TextStyle(color: Colors.grey[600]),
                          ),
                          if (_searchQuery.isEmpty) ...[
                            const SizedBox(height: 16),
                            ElevatedButton.icon(
                              onPressed: () => _showAddEditDialog(),
                              icon: const Icon(Icons.add),
                              label: const Text('Add First Boarding Point'),
                            ),
                          ],
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.all(16),
                      itemCount: _filteredPoints.length,
                      itemBuilder: (context, index) {
                        final point = _filteredPoints[index];
                        return Card(
                          margin: const EdgeInsets.only(bottom: 12),
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: ListTile(
                            leading: Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryColor.withValues(alpha: 0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(
                                Icons.location_on,
                                color: AppTheme.primaryColor,
                              ),
                            ),
                            title: Text(
                              point.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                            subtitle: Text(
                              'Lat: ${point.lat.toStringAsFixed(6)}, Lng: ${point.lng.toStringAsFixed(6)}',
                              style: TextStyle(
                                fontSize: 12,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.edit, size: 20),
                                  color: AppTheme.primaryColor,
                                  onPressed: () => _showAddEditDialog(point: point),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.delete, size: 20),
                                  color: AppTheme.dangerColor,
                                  onPressed: () => _deletePoint(point),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
        ),
      ],
    );
  }
}

