import 'package:shared_preferences/shared_preferences.dart';

/// API Configuration
/// Central configuration file for API endpoints and base URL
class ApiConfig {
  // Production base URL
  static const String baseUrl = 'https://web-production-9625a.up.railway.app';
  
  // Authentication endpoints
  static String get login => '$baseUrl/auth/login';
  static String get register => '$baseUrl/auth/register';
  static String get profile => '$baseUrl/auth/profile';
  
  // Bus endpoints
  static String get buses => '$baseUrl/buses';
  static String bus(int id) => '$baseUrl/buses/$id';
  static String busStops(int id) => '$baseUrl/buses/$id/stops';
  static String busStop(int busId, int stopId) => '$baseUrl/buses/$busId/stops/$stopId';
  
  // Owner endpoints
  static String get ownerBuses => '$baseUrl/owner/buses';
  static String get ownerDashboard => '$baseUrl/owner/dashboard';
  static String get ownerTickets => '$baseUrl/owner/tickets';
  static String get ownerSupervisors => '$baseUrl/owner/supervisors';
  static String get ownerBookings => '$baseUrl/owner/bookings';
  static String get ownerRevenueSummary => '$baseUrl/owner/revenue-summary';
  static String get registerSupervisor => '$baseUrl/owner/register-supervisor';
  static String updateSupervisor(int id) => '$baseUrl/owner/supervisors/$id';
  
  // Location endpoints
  static String busLocation(int id) => '$baseUrl/location/bus/$id';
  static String busLocationUpdate(int id) => '$baseUrl/location/bus/$id/update';
  static String route(int busId) => '$baseUrl/location/route/$busId';
  static String busEta(int busId, int boardingPointId) => '$baseUrl/location/bus/$busId/eta/$boardingPointId';
  static String nearbyPlaces(int boardingPointId) => '$baseUrl/location/boarding-points/$boardingPointId/nearby';
  static String get geocode => '$baseUrl/location/geocode';
  
  // WebSocket endpoints
  static String get wsBooking => 'wss://web-production-9625a.up.railway.app/ws/booking';
  static String wsLocation(int busId) => 'wss://web-production-9625a.up.railway.app/ws/location/$busId';
  
  /// Get authorization headers with JWT token
  static Future<Map<String, String>> getAuthHeaders() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');
    
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }
}

