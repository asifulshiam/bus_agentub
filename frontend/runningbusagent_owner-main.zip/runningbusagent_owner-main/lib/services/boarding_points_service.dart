import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class BoardingPoint {
  final String id;
  final String name;
  final double lat;
  final double lng;
  final DateTime createdAt;

  BoardingPoint({
    required this.id,
    required this.name,
    required this.lat,
    required this.lng,
    required this.createdAt,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'lat': lat,
      'lng': lng,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory BoardingPoint.fromJson(Map<String, dynamic> json) {
    return BoardingPoint(
      id: json['id'] as String,
      name: json['name'] as String,
      lat: (json['lat'] as num).toDouble(),
      lng: (json['lng'] as num).toDouble(),
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }
}

class BoardingPointsService {
  static const String _storageKey = 'boarding_points';

  /// Get all boarding points
  static Future<List<BoardingPoint>> getAll() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonString = prefs.getString(_storageKey);
      
      if (jsonString == null || jsonString.isEmpty) {
        return [];
      }

      final List<dynamic> jsonList = jsonDecode(jsonString);
      return jsonList.map((json) => BoardingPoint.fromJson(json as Map<String, dynamic>)).toList();
    } catch (e) {
      print('Error loading boarding points: $e');
      return [];
    }
  }

  /// Add a new boarding point
  static Future<bool> add(BoardingPoint point) async {
    try {
      final points = await getAll();
      points.add(point);
      return await _saveAll(points);
    } catch (e) {
      print('Error adding boarding point: $e');
      return false;
    }
  }

  /// Update an existing boarding point
  static Future<bool> update(BoardingPoint point) async {
    try {
      final points = await getAll();
      final index = points.indexWhere((p) => p.id == point.id);
      
      if (index == -1) {
        return false;
      }

      points[index] = point;
      return await _saveAll(points);
    } catch (e) {
      print('Error updating boarding point: $e');
      return false;
    }
  }

  /// Delete a boarding point
  static Future<bool> delete(String id) async {
    try {
      final points = await getAll();
      points.removeWhere((p) => p.id == id);
      return await _saveAll(points);
    } catch (e) {
      print('Error deleting boarding point: $e');
      return false;
    }
  }

  /// Get a boarding point by ID
  static Future<BoardingPoint?> getById(String id) async {
    try {
      final points = await getAll();
      return points.firstWhere(
        (p) => p.id == id,
        orElse: () => throw Exception('Not found'),
      );
    } catch (e) {
      return null;
    }
  }

  /// Search boarding points by name
  static Future<List<BoardingPoint>> search(String query) async {
    try {
      final points = await getAll();
      if (query.isEmpty) {
        return points;
      }
      
      final lowerQuery = query.toLowerCase();
      return points.where((point) {
        return point.name.toLowerCase().contains(lowerQuery);
      }).toList();
    } catch (e) {
      return [];
    }
  }

  /// Save all boarding points to storage
  static Future<bool> _saveAll(List<BoardingPoint> points) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final jsonList = points.map((p) => p.toJson()).toList();
      final jsonString = jsonEncode(jsonList);
      return await prefs.setString(_storageKey, jsonString);
    } catch (e) {
      print('Error saving boarding points: $e');
      return false;
    }
  }

  /// Generate a unique ID for a new boarding point
  static String generateId() {
    return DateTime.now().millisecondsSinceEpoch.toString();
  }
}

