import 'package:busapp/config/api_config.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AuthService {
  /// Check if user has a stored token (without network validation)
  /// Token validation will happen when API calls return 401
  static Future<bool> hasToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');
    return token != null && token.isNotEmpty;
  }
  
  /// Check if user is authenticated and token is valid
  static Future<bool> isAuthenticated() async {
    // Just check if token exists - validation happens on API calls
    return await hasToken();
  }
  
  /// Get current user role
  static Future<String?> getUserRole() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_role');
  }
  
  /// Check if user is admin (owner/supervisor)
  static Future<bool> isAdmin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('is_admin') ?? false;
  }
  
  /// Clear all authentication data (logout)
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('access_token');
    
    // Optionally revoke token on backend if there's a logout endpoint
    // For now, just clear local storage
    
    await prefs.clear();
  }
  
  /// Get stored user data
  static Future<Map<String, dynamic>?> getUserData() async {
    final prefs = await SharedPreferences.getInstance();
    final userDataString = prefs.getString('user_data');
    
    if (userDataString != null) {
      try {
        return jsonDecode(userDataString) as Map<String, dynamic>;
      } catch (e) {
        return null;
      }
    }
    return null;
  }
}

