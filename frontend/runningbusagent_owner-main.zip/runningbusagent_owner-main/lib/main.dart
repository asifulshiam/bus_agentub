import 'package:busapp/admin_login.dart';
import 'package:busapp/homepage.dart';
import 'package:busapp/owner/main_layout.dart';
import 'package:busapp/services/auth_service.dart';
import 'package:busapp/config/theme.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bus AgentUB - Owner Dashboard',
      theme: AppTheme.lightTheme,
      debugShowCheckedModeBanner: false,
      home: const AuthWrapper(),
      routes: {
        '/admin_login': (context) => const AdminLogin(),
      },
    );
  }
}

class AuthWrapper extends StatefulWidget {
  const AuthWrapper({super.key});

  @override
  State<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends State<AuthWrapper> {
  bool _isLoading = true;
  Widget? _homeWidget;

  @override
  void initState() {
    super.initState();
    _checkAuthState();
  }

  Future<void> _checkAuthState() async {
    try {
      final hasAuth = await AuthService.isAuthenticated();
      
      if (hasAuth) {
        final admin = await AuthService.isAdmin();
        
        if (mounted) {
          setState(() {
            _homeWidget = admin ? const MainLayout() : const HomePage();
            _isLoading = false;
          });
        }
      } else {
        if (mounted) {
          setState(() {
            _homeWidget = const AdminLogin();
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _homeWidget = const AdminLogin();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading || _homeWidget == null) {
      return Scaffold(
        backgroundColor: AppTheme.backgroundColor,
        body: const Center(
          child: CircularProgressIndicator(
            color: AppTheme.primaryColor,
          ),
        ),
      );
    }
    
    return _homeWidget!;
  }
}
